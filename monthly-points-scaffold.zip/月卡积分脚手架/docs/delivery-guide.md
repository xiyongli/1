# 动效交付打包标准（SOP）

> 任何动效调试完成、产品体验通过后，交付研发接入业务代码，统一走本流程。
> 一条命令：`npm run package -- --demo <motion-id>`。

## 一、交付就绪检查（打包前提）

1. `npm run check` 全过（typecheck / eslint / 动效约束 / 生产构建）；
2. 参数已固化：调参面板确认的最终值写进 `config.ts` 的 `DEFAULT_CONFIG`（或组件默认 props），即设计师拍板值；
3. 死资源已清：媒体目录即依赖清单，未被 import 的资源已删除；
4. demo 目录含 `delivery.md`（研发接入说明：组件契约 / API 速览 / 接入步骤 / SSR 注意 / 降级与性能 / 验收基准）——动效定稿时由 Agent 编写并随代码维护。

## 二、打包

```bash
npm run package -- --demo <id>
```

脚本（`scripts/package-demo.mjs`）自动做五件事：

1. 拷贝 demo 目录，**剔除调试件**（`workshop.tsx` / `workshop.module.scss`）与过程文档（规格书 / 复盘报告等 `*.md`）；
2. **依赖边界扫描**：`@shared` / `@hooks` / `@utils` / `@pdd` 引用与越出 demo 目录的相对 import 会被警告并写入 DELIVERY.md，需人工确认随包附带；
3. 统计源码规模与媒体体积、解析 registry 元信息、收集外部依赖版本；
4. `npm run preview` 产出**效果基准** `preview-baseline.html`；
5. 生成 `DELIVERY.md`（自动事实 + 内联 `delivery.md` 接入说明），压 zip。

产物：`dist-packages/<motion-id>-delivery-<日期>.zip`（目录已 gitignore，二进制不进仓库）。

标准包结构：

```
<motion-id>-delivery/
├── DELIVERY.md              # 交付说明：包内容 / 运行依赖 / 接入说明
├── preview-baseline.html    # 效果基准：验收金标准，双击即看
├── index.tsx 等             # 动效源码（含业务组件入口）
└── media/ 等                # 资源（import 驱动，无死资源）
```

## 三、zip 放哪：Artifacts 网盘 + 分享链接

仓库不存二进制交付物，标准去向：

1. 上传 zip 到 **Artifacts 网盘**（Comagic 可代传：`create_item` → PUT 上传）；
2. 创建**分享链接**（可设过期时间）发给研发；
3. 交付记录（链接 + 版本日期 + 验收结论）回写到需求（Brook 评论）或交付文档存档。

## 四、验收闭环

1. 研发接入业务工程后，与 `preview-baseline.html` **同参数对照**，表现一致即通过；
2. 真机抽测：2020 年后中端机流畅度 + 一台低端机看降级表现（低端机降档）；
3. 有偏差 → 回工坊修复 → 重新打包（文件名带日期自动区分版本）→ 重新上传分享。

## 五、何时升级为 npm 私源包

单业务一次性接入用源码目录交付即可；出现以下情况再升级为 npm.pdd.net 私源包：

- 多个业务工程要接入同一动效；
- 动效需要长期迭代发版。

升级时把同一目录发布为包（`peerDependencies: react, three`），目录结构无需改动，本流程的 DELIVERY.md / 基准产物约定继续沿用。
