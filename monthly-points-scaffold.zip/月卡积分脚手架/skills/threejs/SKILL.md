---
name: threejs
description: "Three.js 3D 开发参考技能。当要修改的文件中存在 `from 'three'` 或 `import * as THREE` 导入时，必须使用此技能。涵盖场景搭建、几何体、材质、光照、动画、交互、资源加载、着色器、后处理和纹理。提到「Three.js」「3D 场景」「WebGLRenderer」「GLSL」「ShaderMaterial」「后处理」「Bloom」「光照」「阴影」「GLTF 加载」等任何 Three.js 相关内容时，都应使用此技能。"
---

# Three.js 3D 开发参考

本技能是 Three.js 参考文档的**统一入口**。所有 Three.js 专题参考文档嵌套在 `references/` 目录下，不会单独出现在可用技能列表中，由本入口按需加载。

## 工程适配（本工程硬约束，优先于通用参考）

本工程是移动端 H5 动效工坊（目标 iOS 12+ / Android 8+，2020 年后中端机主交互 ≥50fps）。references/ 中的通用写法面向桌面端，落地到本工程时**工程规则（根 `AGENTS.md` + `src/motion_playground/MOTION_RULES.md` A–G）优先**，关键映射：

| 通用写法 | 本工程约束 |
| --- | --- |
| three.js 任意版本 | 锁定 0.185.x（`package.json` `^0.185.1`），不升级不降级 |
| Bloom / DOF / blur 类后处理（postprocessing.md） | C1 提示档：低端机掉帧风险高，使用前必须向用户提示影响与替代方案（预烘焙序列图 / 静态模糊），由用户拍板 |
| 阴影（shadowMap）、多光源（lighting.md） | 移动端慎用：每盏阴影光源都是额外渲染通道；优先贴图假阴影；draw call ≤30（C3，口径 = 网格 × 材质组） |
| 高分辨率纹理（textures.md / loaders.md） | 纹理边长 ≤1024（D2）；单图 >100KB 用 WebP；GLSL 字面量经 uniform 注入（E1）；实时（程序化 CanvasTexture/DataTexture）生成纹理移动端成本高，尽量避免，优先静态贴图 / 预烘焙 |
| OrbitControls 等控制器自建监听/循环（interaction.md） | 一个动效一个主 rAF 循环（B1）：控制器只用于工坊调试或挂入主循环；demo 内交互自写手势并统一登记 detach（E5） |
| GLTF/Draco/KTX2 异步加载（loaders.md） | 加载门控（B3）：未就绪元素从构造期就不可见，就绪判定用全量资源计数，必须设兜底超时，降级路径同门控 |
| 运行时 `new Geometry/Material/Texture`（geometry.md / materials.md） | A2：渲染资源只在构造期创建，参数化变化走 scale / uniform / 顶点更新 |
| 每帧无条件写 uniform / color / opacity | A4：值变才写（缓存 diff） |
| 逐颗粒子 Mesh（geometry.md Points） | C6：持续粒子统一「SoA Float32Array 模拟层 + 单 THREE.Points + ShaderMaterial」= 1 draw call |
| 新增 Canvas / 离屏 CanvasTexture（textures.md） | Canvas 数量越少越好：转场动效用多场景思路复用同一个 Canvas（多 scene 切换而非新 Canvas），如果不满足要求才新增；离屏 CanvasTexture 优先复用同一张画布；引入 Canvas 后其余动画尽量同栈实现，避免技术栈杂乱 |
| 帧循环常驻渲染 | B2/B3：弹簧 settle 即 `cancelAnimationFrame`；`visibilitychange` / 被遮挡时停表 |
| 子场景 / 子功能全量渲染 | 按需渲染：有触发条件的子功能不要一上来就渲染出来，触发后再挂载 / 起播 |
| 任意渲染代码 | 卸载必须：kill 全部 tween + removeEventListener + dispose 几何/材质/纹理，做好内存管理；G1：交付前挂卸冒烟（mount → unmount → mount），dispose 幂等；`npm run check` 全过 |

## 强制规则

当要修改的文件中存在 `from 'three'` 或 `import * as THREE` 导入时，**必须主动加载**本技能，并根据代码中实际使用的 Three.js API 按以下映射**同时读取**对应参考文档（可同时命中多个）：

## API → 参考文档映射

| 代码特征（API / 类名 / 关键词） | 参考文档 |
| --- | --- |
| `Scene` / `Camera` / `WebGLRenderer` / `Object3D` / `Group` / `Matrix4` / `Vector3` | [fundamentals.md](./references/fundamentals.md) |
| `*Geometry` / `BufferGeometry` / `InstancedMesh` / `Points` / `Float32Array`（顶点数据） | [geometry.md](./references/geometry.md) |
| `*Material` / `onBeforeCompile` / `transparent` / `opacity` / `depthWrite` | [materials.md](./references/materials.md) |
| `*Light` / `Shadow` / `shadowMap` / `AmbientLight` / `DirectionalLight` | [lighting.md](./references/lighting.md) |
| `AnimationMixer` / `KeyframeTrack` / `Clock` / `Skeleton` / `morphTarget` | [animation.md](./references/animation.md) |
| `Raycaster` / `OrbitControls` / `PointerLockControls` / `DragControls` | [interaction.md](./references/interaction.md) |
| `GLTFLoader` / `TextureLoader` / `LoadingManager` / `RGBELoader` | [loaders.md](./references/loaders.md) |
| `ShaderMaterial` / `GLSL` / `onBeforeCompile` / `varying` / `uniform` / `gl_FragColor` | [shaders.md](./references/shaders.md) |
| `EffectComposer` / `RenderPass` / `*Pass` / `postprocessing` | [postprocessing.md](./references/postprocessing.md) |
| `TextureLoader` / `UV` / `DataTexture` / `CanvasTexture` / `CubeTexture` / `colorSpace` | [textures.md](./references/textures.md) |

> **注意**：`TextureLoader` 和 `onBeforeCompile` 等关键词可能同时命中多个参考文档，全部读取即可。

## 参考文档清单

| 文档 | 涵盖内容 |
| --- | --- |
| [fundamentals.md](./references/fundamentals.md) | 场景搭建、相机、渲染器、Object3D 层级、坐标系、数学工具 |
| [geometry.md](./references/geometry.md) | 内置几何体、BufferGeometry、自定义几何体、InstancedMesh、Points/Lines |
| [materials.md](./references/materials.md) | PBR 材质、Basic/Phong/Toon 材质、ShaderMaterial、环境贴图 |
| [lighting.md](./references/lighting.md) | 光源类型、阴影配置、IBL 环境光照、光照方案 |
| [animation.md](./references/animation.md) | 关键帧动画、骨骼动画、形变目标、动画混合、程序化动画 |
| [interaction.md](./references/interaction.md) | Raycaster、相机控制、拖拽、选择系统、坐标转换 |
| [loaders.md](./references/loaders.md) | GLTF/Draco/KTX2 加载、LoadingManager、异步加载、缓存 |
| [shaders.md](./references/shaders.md) | GLSL 语法、ShaderMaterial、着色器模式、onBeforeCompile |
| [postprocessing.md](./references/postprocessing.md) | EffectComposer、Bloom、DOF、后处理特效、自定义 ShaderPass |
| [textures.md](./references/textures.md) | 纹理类型、UV 映射、环境贴图、Render Target、纹理管理 |
