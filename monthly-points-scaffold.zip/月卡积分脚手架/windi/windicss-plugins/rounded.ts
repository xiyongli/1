import plugin from 'windicss/plugin';

import { isNum, isPx } from './util';

const directionMaps = {
    t: ['border-top-left-radius', 'border-top-right-radius'],
    l: ['border-top-left-radius', 'border-bottom-left-radius'],
    b: ['border-bottom-left-radius', 'border-bottom-right-radius'],
    r: ['border-top-right-radius', 'border-bottom-right-radius'],
    tl: ['border-top-left-radius'],
    tr: ['border-top-right-radius'],
    bl: ['border-bottom-left-radius'],
    br: ['border-bottom-right-radius'],
    all: ['border-radius']
};

export default plugin(({ addDynamic }) => {
    addDynamic(
        'rounded',
        ({ Utility, Style, Property }) => {
            const { raw } = Utility;
            const roundRe = /^rounded-((t|l|b|r|tl|tr|bl|br)-)?(\d+(\.\d+)?(PX)?)$/;
            const result = raw.match(roundRe);
            if (result) {
                const tag = result[2] || 'all';
                const amount = result[3];
                const directions = directionMaps[tag];
                if (isNum(amount)) {
                    return Style(
                        Utility.class,
                        directions.map(direction => {
                            return Property(direction, `${amount}px`);
                        })
                    );
                }

                if (isPx(amount)) {
                    return Style(
                        Utility.class,
                        directions.map(direction => {
                            return Property(direction, amount);
                        })
                    );
                }
            }
        },
        {
            layer: 'utilities'
        }
    );
});
