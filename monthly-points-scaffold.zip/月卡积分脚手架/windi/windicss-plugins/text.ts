import plugin from 'windicss/plugin';
import { toRGB } from 'windicss/utils';

import { colorRegFactory, isNum, isPx } from './util';

export default plugin(({ addDynamic }) => {
    addDynamic(
        'text',
        ({ Utility, Style, Property }) => {
            const { raw, amount, absolute } = Utility;
            // 字体颜色
            const result = raw.match(colorRegFactory('text'));
            if (result) {
                const color = result[1];
                let value = '';
                if (color.startsWith('#')) {
                    value = `rgb(${toRGB(color).join(',')})`;
                } else {
                    value = color;
                }
                return Property('color', value);
            }

            // 数字处理 24 ==> 24px
            if (isNum(amount) && absolute.startsWith('text')) {
                return Style(Utility.class, Property('font-size', `${amount}px`));
            }

            if (isPx(amount) && absolute.startsWith('text')) {
                return Style(Utility.class, Property('font-size', amount));
            }
        },
        {
            layer: 'utilities'
        }
    );
});
