import plugin from 'windicss/plugin';

import { isNum, translateDirection } from './util';
const xyz = ['x', 'y', 'z'];
export default plugin(({ addDynamic }) => {
    // 变换
    addDynamic('translate', ({ Utility, Style, Property }) => {
        const { isNegative, amount, raw, body } = Utility;
        const re = /^-?translate-/;
        if (!raw.match(re)) return undefined;
        const directions = translateDirection(body);
        const sign = isNegative ? '-' : '';
        if (isNum(amount) && directions.length > 0) {
            const size = `${sign}${amount}px`;
            const propValue = directions
                .map(direction => {
                    return `translate${direction}(${size})`;
                })
                .join(' ');
            return Style(Utility.class, Property('transform', propValue));
        }
        // eslint-disable-next-line no-useless-escape
        const reg = /\[([0-9\.]*%)\]/;
        if (reg.test(amount) && directions.length > 0) {
            const radio = amount.match(reg)?.[1];
            const size = `${sign}${radio}`;
            const propValue = directions
                .map(direction => {
                    return `translate${direction}(${size})`;
                })
                .join(' ');
            return Style(Utility.class, Property('transform', propValue));
        }
        const fractionRe = /^\d+\/\d+$/;
        if (fractionRe.test(amount) && directions.length > 0) {
            try {
                const val = Number(eval(amount)) * 100;
                const size = `${sign}${val}%`;
                const propValue = directions
                    .map(direction => {
                        return `translate${direction}(${size})`;
                    })
                    .join(' ');
                return Style(Utility.class, Property('transform', propValue));
            } catch (error) {
                return undefined;
            }
        }
    });

    addDynamic('scale', ({ Utility, Style, Property }) => {
        const { amount, center } = Utility;
        const scale = Number(amount) / 100;
        if (isNaN(scale)) return undefined;
        const prop = xyz.includes(center) ? `scale${center.toLocaleUpperCase()}(${scale})` : `scale(${scale})`;
        return Style(Utility.class, Property('transform', prop));
    });

    addDynamic('skew', ({ Utility, Style, Property }) => {
        const { amount, center, isNegative } = Utility;
        const val = isNegative ? `-${amount}` : amount;
        const prop = xyz.includes(center) ? `skew${center.toLocaleUpperCase()}(${val}deg)` : `skew(${val}deg)`;
        return Style(Utility.class, Property('transform', prop));
    });
    addDynamic('rotate', ({ Utility, Style, Property }) => {
        const { amount, center, isNegative } = Utility;
        const val = isNegative ? `-${amount}` : amount;
        const prop = xyz.includes(center) ? `rotate${center.toLocaleUpperCase()}(${val}deg)` : `rotate(${val}deg)`;
        return Style(Utility.class, Property('transform', prop));
    });
});
