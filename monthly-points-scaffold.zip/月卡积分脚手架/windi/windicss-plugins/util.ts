export const isInt = (str: string): boolean => {
    return /^[1-9]\d*$|^0$/.test(str);
};

export const isFloat = (str: string): boolean => {
    return /^([1-9]\d*|0)\.\d+$/.test(str);
};

export const isNum = (str: string): boolean => {
    return isInt(str) || isFloat(str);
};

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const isNull = (o: any): boolean => {
    return o === undefined || o === null;
};

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const isPx = (str: any): boolean => {
    if (typeof str !== 'string') return false;
    const unit = str.slice(-2);
    const num = str.replace('PX', '');
    return isNum(num) && unit === 'PX';
};

export const translateDirection = (body: string = ''): string[] => {
    let result = [];
    if (body.startsWith('x')) {
        result = ['X'];
    } else if (body.startsWith('y')) {
        result = ['Y'];
    } else if (body.startsWith('z')) {
        result = ['Z'];
    } else if (body.startsWith('3d')) {
        result = ['X', 'Y', 'Z'];
    } else {
        result = ['X', 'Y'];
    }
    return result;
};

// const re = /\[(#\w{6}|rgb\(\d{1,3},\d{1,3},\d{1,3}\)|rgba\(\d{1,3},\d{1,3},\d{1,3},(1|0\.\d+)\))\]/;

export const colorRegFactory = (prefix: string): RegExp => {
    const re = new RegExp(
        '^' +
            prefix +
            '-\\[(#\\w{6}|rgb\\(\\d{1,3},\\d{1,3},\\d{1,3}\\)|rgba\\(\\d{1,3},\\d{1,3},\\d{1,3},(1|0\\.\\d+)\\))\\]$'
    );
    return re;
};
