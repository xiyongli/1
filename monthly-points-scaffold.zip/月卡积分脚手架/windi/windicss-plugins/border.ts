import plugin from 'windicss/plugin';
import { toRGB } from 'windicss/utils';

import { colorRegFactory, isNum, isPx } from './util';

export default plugin(({ addDynamic }) => {
    addDynamic(
        'border',
        ({ Utility, Style, Property }) => {
            const { amount, raw, absolute } = Utility;
            // 边框颜色
            const result = raw.match(colorRegFactory('text'));
            if (result) {
                const color = result[1];
                let value = '';
                if (color.startsWith('#') && color) {
                    value = `rgb(${(toRGB(color) as number[]).join(',')})`;
                } else {
                    value = color;
                }
                return Property('color', value);
            }
            // 边框宽度
            if (isNum(amount) && absolute.startsWith('border')) {
                const map = { t: 'top', b: 'bottom', l: 'left', r: 'right' };
                const direct = Object.keys(map).includes(absolute[7]) ? map[absolute[7]] : '';
                if (direct) {
                    return Style(Utility.class, [
                        Property(`border-${direct}-width`, `${amount}px`),
                        // 默认边框样式solid
                        Property(`border-${direct}-style`, 'solid')
                    ]);
                }

                return Style(Utility.class, [
                    Property('border-width', `${amount}px`),
                    // 默认边框样式solid
                    Property('border-style', 'solid')
                ]);
            }
            // 保留px，不转rem
            if (isPx(amount) && absolute.startsWith('border')) {
                return Style(Utility.class, [Property('border-width', amount), Property('border-style', 'solid')]);
            }
        },
        {
            layer: 'utilities'
        }
    );
});
