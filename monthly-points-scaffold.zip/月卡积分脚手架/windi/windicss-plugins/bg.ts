import plugin from 'windicss/plugin';
import { toRGB } from 'windicss/utils';

import { colorRegFactory } from './util';

export default plugin(({ addDynamic }) => {
    addDynamic(
        'bg',
        ({ Utility, Style, Property }) => {
            const { amount, raw } = Utility;

            // 图片铺满居中
            if (amount === 'full') {
                return Style.generate(Utility.class, {
                    backgroundPosition: 'center center',
                    backgroundSize: '100% 100%',
                    backgroundRepeat: 'no-repeat'
                });
            }

            // 背景颜色
            const result = raw.match(colorRegFactory('bg'));
            if (result) {
                const color = result[1];
                let value = '';
                if (color.startsWith('#') && color) {
                    value = `rgb(${(toRGB(color) as number[]).join(',')})`;
                } else {
                    value = color;
                }
                return Property('background-color', value);
            }
        },
        {
            layer: 'utilities'
        }
    );
    // background-image:linear-gradient(to bottom, rgba(255,255,0,0.5), rgba(0,0,255,0.5)))
    // linear-tr-[#ffffff,#ff0000]
    addDynamic('linear', ({ Utility, Style, Property }) => {
        const { raw, body } = Utility;
        const re = /^linear-/;

        if (!raw.match(re)) return undefined;
        // const reg = /([tlbr]{1,2})-\[(#\w+),(#\w+)\]/;
        const reg = /([tlbr]{1,2}|[0-9]{1,3})-\[(.+),(.+)\]/;
        const matchRes = body.match(reg) || [];

        if (matchRes.length === 4) {
            // ['tr-[#ffffff,#ff0000]', 'tr', '#ffffff', '#ff0000']
            const direction = matchRes[1];
            const directionMap = {
                t: 'top',
                b: 'bottom',
                l: 'left',
                r: 'right',
                tr: 'top right',
                rt: 'top right',
                br: 'bottom right',
                rb: 'bottom right',
                bl: 'bottom left',
                lb: 'bottom left',
                tl: 'top left',
                lt: 'top left'
            };
            const directionRes = directionMap[direction];

            const startColor = matchRes[2]?.replace('-', ' ');
            const endColor = matchRes[3]?.replace('-', ' ');

            if (directionRes) {
                const propValue = `linear-gradient(to ${directionRes}, ${startColor}, ${endColor})`;
                return Style(Utility.class, Property('background-image', propValue));
            }

            // 带角度渐变
            const propValue = `linear-gradient(${direction}deg, ${startColor}, ${endColor})`;
            return Style(Utility.class, Property('background-image', propValue));
        }
    });
});
