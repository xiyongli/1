import plugin from 'windicss/plugin';

enum ShadowPattern {
    textShadow = 1,
    boxShadow = 2
}

const matchShadowPattern = (str: string) => {
    // eslint-disable-next-line no-useless-escape
    const reg = /\[([^\[\]]*?)\]/g;
    if (!str) return [];
    return str.match(reg) || [];
};
// 多组shadow, 每一组都valid才能
const validCheck = (arr, pattern) => {
    const compareLen = pattern === ShadowPattern.textShadow ? 4 : 5;
    return arr.filter(item => item.length === compareLen).length === arr.length;
};

const shadowPositionMatch = (pattern: ShadowPattern, amount) => {
    const shadowPattern = matchShadowPattern(amount);
    const shadowPositionReg =
        pattern === ShadowPattern.textShadow
            ? /\[(-?\d+),(-?\d+),(-?\d+).*\]/
            : /\[(-?\d+),(-?\d+),(-?\d+),(-?\d+).*\]/;
    const res: string[][] = [];
    shadowPattern.forEach(sp => {
        const _spTemp = sp.match(shadowPositionReg);
        const rgbReg = /(#\w{6}|rgb\(\d{1,3},\d{1,3},\d{1,3}\)|rgba\(\d{1,3},\d{1,3},\d{1,3},(1|0\.\d+)\))\]$/;
        const _spColor = sp.match(rgbReg);
        if (_spTemp && _spColor) {
            if (pattern === ShadowPattern.textShadow) {
                res.push([_spTemp[1], _spTemp[2], _spTemp[3], _spColor[1]]);
            } else {
                res.push([_spTemp[1], _spTemp[2], _spTemp[3], _spTemp[4], _spColor[1]]);
            }
        }
    });
    return res;
};
export default plugin(({ addDynamic }) => {
    addDynamic(
        'text-shadow',
        ({ Utility, Style, Property }) => {
            const { amount } = Utility;
            if (amount === 'none') {
                return Style(Utility.class, Property('text-shadow', amount));
            }
            const res = shadowPositionMatch(ShadowPattern.textShadow, amount);
            if (validCheck(res, ShadowPattern.textShadow)) {
                const cssValue = res
                    .reduce((acc, cur) => {
                        return acc + `${cur[0]}px ${cur[1]}px ${cur[2]}px ${cur[3]},`;
                    }, '')
                    .slice(0, -1);
                return Style(Utility.class, Property('text-shadow', cssValue));
            }
        },
        {
            layer: 'utilities'
        }
    );
    addDynamic(
        'box-shadow-inset',
        ({ Utility, Style, Property }) => {
            const { amount } = Utility;

            const res = shadowPositionMatch(ShadowPattern.boxShadow, amount);
            if (validCheck(res, ShadowPattern.boxShadow)) {
                const cssValue = res
                    .reduce((acc, cur) => {
                        return acc + `${cur[0]}px ${cur[1]}px ${cur[2]}px ${cur[3]}px ${cur[4]},`;
                    }, 'inset ')
                    .slice(0, -1);
                return Style(Utility.class, Property('box-shadow', cssValue));
            }
        },
        {
            layer: 'utilities'
        }
    );
    addDynamic(
        'box-shadow',
        ({ Utility, Style, Property }) => {
            const { amount } = Utility;

            const res = shadowPositionMatch(ShadowPattern.boxShadow, amount);
            if (validCheck(res, ShadowPattern.boxShadow)) {
                const cssValue = res
                    .reduce((acc, cur) => {
                        return acc + `${cur[0]}px ${cur[1]}px ${cur[2]}px ${cur[3]}px ${cur[4]},`;
                    }, '')
                    .slice(0, -1);
                return Style(Utility.class, Property('box-shadow', cssValue));
            }
        },
        {
            layer: 'utilities'
        }
    );
});
