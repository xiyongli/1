import bgPlugin from './bg';
import borderPlugin from './border';
import componentsPlugin from './components';
import roundedPlugin from './rounded';
import shadowPlugin from './shadow';
import sizePlugin from './size';
import textPlugin from './text';
import transformPlugin from './transform';

export default [
    shadowPlugin,
    componentsPlugin,
    sizePlugin,
    textPlugin,
    bgPlugin,
    borderPlugin,
    roundedPlugin,
    transformPlugin
];
