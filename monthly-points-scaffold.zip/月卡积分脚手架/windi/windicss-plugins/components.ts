import plugin from 'windicss/plugin';

export default plugin(({ addComponents }) => {
    addComponents(
        {
            '.abs-center': {
                position: 'absolute',
                left: '50%',
                top: '50%',
                transform: 'translate(-50%, -50%)'
            },
            '.abs-x-center': {
                position: 'absolute',
                left: '50%',
                transform: 'translateX(-50%)'
            },
            '.abs-y-center': {
                position: 'absolute',
                top: '50%',
                transform: 'translateY(-50%)'
            },
            '.flex-center': {
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
            },
            '.pfr': {
                fontFamily: '"PingFang SC", sans-serif'
            },
            '.pfm': {
                fontFamily: 'PingFangSC-Medium, sans-serif'
            },
            '.pfs': {
                fontFamily: 'PingFangSC-Semibold, sans-serif'
            },
            '.fit-content': {
                width: 'fit-content'
            },
            '.line-one': {
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                whiteSpace: 'nowrap'
            },
            '.line-two': {
                display: '-webkit-box',
                '-webkit-line-clamp': '2',
                '-webkit-box-orient': 'vertical',
                overflow: 'hidden',
                textOverflow: 'ellipsis'
            },
            '.line-three': {
                display: '-webkit-box',
                '-webkit-line-clamp': '3',
                '-webkit-box-orient': 'vertical',
                overflow: 'hidden',
                textOverflow: 'ellipsis'
            },
            '.art-font': {
                backgroundPosition: '50% 50%',
                backgroundSize: '98% 90%',
                backgroundRepeat: 'no-repeat',
                WebkitTextFillColor: 'transparent',
                WebkitBackgroundClip: 'text'
            },
            /**
             * 通用奖励弹窗字体，不满足可以在css中上传字体
             */
            '.art-puhui-popup': {
                fontFamily: 'PuHuiTi-Bold-Base-Popup'
            },
            /**
             * 数字字体（0-9，）
             */
            '.num-FontMiSansHeavy': {
                fontFamily: 'Font-MiSans-Heavy'
            },
            /**
             * 数字字体（0-9，）
             */
            '.num-FontMiSansBold': {
                fontFamily: 'Font-MiSans-Bold'
            },
            /**
             * 数字字体（0-9，）
             */
            '.num-FontMiSansDemibold': {
                fontFamily: 'Font-MiSans-Demibold'
            },
            '.num-PDDSansStd06': {
                fontFamily: 'Font-PDDSansStd06-Regular'
            },
            '.num-FontFixWidthNum': {
                fontFamily: 'Helvetica-Neue-2'
            }
        },
        {
            layer: 'components'
        }
    );
});
