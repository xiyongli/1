import plugin from 'windicss/plugin';
import { expandDirection } from 'windicss/utils';

import { isNull, isNum, isPx } from './util';

const sizePropertyMap = {
    w: 'width',
    h: 'height',
    leading: 'line-height',
    indent: 'text-indent',
    top: 'top',
    left: 'left',
    right: 'right',
    bottom: 'bottom'
};

export default plugin(({ addDynamic }) => {
    Object.keys(sizePropertyMap).forEach(key => {
        addDynamic(key, ({ Utility, Style, Property }) => {
            const { amount, isNegative, absolute } = Utility;
            const property = sizePropertyMap[key];
            const sign = isNegative ? '-' : '';
            if (isNum(amount) && absolute.startsWith(key + '-')) {
                return Style(Utility.class, Property(property, `${sign}${amount}px`));
            }
            if (isPx(amount) && absolute.startsWith(key)) {
                return Style(Utility.class, Property(property, sign + amount));
            }
        });
    });

    addDynamic('p', ({ Utility, Style, Property }) => {
        const { identifier, amount, absolute } = Utility;
        const directions = expandDirection(identifier.substring(1), false);
        if (directions && !isNull(amount) && isNum(amount) && absolute.startsWith('p')) {
            const value = amount === '0' ? amount : `${amount}px`;
            if (directions[0] === '*') {
                return Style(Utility.class, Property('padding', value));
            } else {
                return Style(
                    Utility.class,
                    directions.map(direction => {
                        return Property(`padding-${direction}`, value);
                    })
                );
            }
        }
    });

    addDynamic('m', ({ Utility, Style, Property }) => {
        const { amount, isNegative, identifier, absolute } = Utility;
        const directions = expandDirection(identifier.substring(1), false);
        if (directions && isNum(amount) && !isNull(amount) && absolute.startsWith('m')) {
            const value = amount === '0' ? amount : isNegative ? `-${amount}px` : `${amount}px`;
            if (directions[0] === '*') {
                return Style(Utility.class, Property('margin', value));
            } else {
                return Style(
                    Utility.class,
                    directions.map(direction => {
                        return Property(`margin-${direction}`, value);
                    })
                );
            }
        }
    });

    ['min', 'max'].forEach(item => {
        addDynamic(item, ({ Utility, Style, Property }) => {
            const { raw } = Utility;
            const re = /^(min|max)-[w|h]-/;
            if (!raw.match(re)) return undefined;
            const body = raw.replace(re, '');
            const prop = raw
                .substring(0, 5)
                .replace('h', 'height')
                .replace('w', 'width');
            if (isNum(body) && prop) {
                return Style(Utility.class, Property(prop, `${body}px`));
            }
        });
    });
});
