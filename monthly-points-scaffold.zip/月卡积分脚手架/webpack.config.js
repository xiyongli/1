const path = require('path');
const webpack = require('webpack');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const WindiCSSWebpackPlugin = require('windicss-webpack-plugin');

/** 体积告警只在生产构建启用：开发预览使用未压缩的 React 开发版，体积大属正常现象 */
const isProduction = process.env.NODE_ENV === 'production';

/**
 * 需要过 babel 转译的 node_modules 白名单：
 * - @esotericsoftware / @pixi / pixi.js 发布产物含较新 ES 语法，转译以覆盖 iOS 12 / Android 8
 */
const TRANSPILE_NODE_MODULES = [
    /[\\/]node_modules[\\/]@esotericsoftware[\\/]/,
    /[\\/]node_modules[\\/]@pixi[\\/]/,
    /[\\/]node_modules[\\/]pixi\.js[\\/]/
];

/**
 * 配置以函数形式导出，通过 `--env preview` 开启单文件预览模式：
 * - 图片、字体、音频全部转成 base64 内联，不再产出独立资源文件
 * - 合并全部 chunk（registry 懒加载会切出 motion、vendors 等分块，
 *   inline-preview.mjs 只内联 HTML 引用的 main 并删除 assets 目录，
 *   不合并的话懒加载分块会丢失，单文件预览点进动效必然 404）
 * - 配合 scripts/inline-preview.mjs 将 JS 内联进 HTML，最终只生成一个 preview/index.html
 */
module.exports = (env = {}) => {
    const isPreview = Boolean(env.preview);
    // 普通构建：4KB 以下图片转 base64；preview：全部内联
    const inlineMaxSize = isPreview ? Infinity : 4096;

    return {
        entry: path.resolve(__dirname, 'src/index.tsx'),
        output: {
            path: path.resolve(__dirname, 'dist'),
            filename: 'assets/[name].[contenthash:8].js',
            assetModuleFilename: 'assets/[name].[contenthash:8][ext]',
            clean: true
        },
        devtool: process.env.NODE_ENV === 'production' ? 'source-map' : 'cheap-module-source-map',
        resolve: {
            extensions: ['.tsx', '.ts', '.js'],
            alias: {
                '@hooks': path.resolve(__dirname, 'src/hooks'),
                '@playground': path.resolve(__dirname, 'src/motion_playground'),
                '@shared': path.resolve(__dirname, 'src/shared'),
                '@styles': path.resolve(__dirname, 'src/styles'),
                '@utils': path.resolve(__dirname, 'src/utils')
            }
        },
        module: {
            rules: [
                {
                    test: /\.[jt]sx?$/,
                    exclude: filePath =>
                        /node_modules/.test(filePath) && !TRANSPILE_NODE_MODULES.some(re => re.test(filePath)),
                    use: {
                        loader: 'babel-loader',
                        options: {
                            presets: [
                                ['@babel/preset-env', { useBuiltIns: false }],
                                ['@babel/preset-react', { runtime: 'classic' }],
                                '@babel/preset-typescript'
                            ]
                        }
                    }
                },
                {
                    test: /\.module\.scss$/,
                    use: [
                        'style-loader',
                        {
                            loader: 'css-loader',
                            options: {
                                modules: {
                                    localIdentName: '[name]__[local]--[hash:base64:5]',
                                    // scss 允许 kebab-case 类名，但 TS 侧统一以 camelCase 取值（styles.sectionTitle）
                                    exportLocalsConvention: 'camelCase'
                                }
                            }
                        },
                        'postcss-loader',
                        'sass-loader'
                    ]
                },
                {
                    test: /\.scss$/,
                    exclude: /\.module\.scss$/,
                    use: ['style-loader', 'css-loader', 'postcss-loader', 'sass-loader']
                },
                {
                    test: /\.css$/,
                    use: ['style-loader', 'css-loader', 'postcss-loader']
                },
                {
                    test: /\.(png|jpe?g|gif|webp|avif|mp3|glb)$/i,
                    type: 'asset',
                    parser: { dataUrlCondition: { maxSize: inlineMaxSize } }
                },
                {
                    test: /\.(woff2?|ttf)$/i,
                    // preview 模式下字体也内联为 base64，保证单文件产物
                    type: isPreview ? 'asset' : 'asset/resource',
                    parser: { dataUrlCondition: { maxSize: inlineMaxSize } }
                }
            ]
        },
        plugins: [
            new HtmlWebpackPlugin({
                template: path.resolve(__dirname, 'public/index.html'),
                scriptLoading: 'defer'
            }),
            // WindiCSS：按 windi.config.ts 的 extract 范围扫描 src 源码生成虚拟模块 windi.css
            new WindiCSSWebpackPlugin(),
            // vendored 播放器源码（src/shared/ddgyPlayer/vendor）读取 process.env.platform / process.env.BROWSER（浏览器无 process 全局，需静态替换）
            new webpack.DefinePlugin({
                'process.env.platform': JSON.stringify(''),
                'process.env.BROWSER': JSON.stringify('true')
            }),
            // preview 单文件模式：合并全部 chunk（见文件头注释）
            ...(isPreview
                ? [new webpack.optimize.LimitChunkCountPlugin({ maxChunks: 1 })]
                : [])
        ],
        devServer: {
            host: '127.0.0.1',
            port: 3023,
            hot: true,
            open: true,
            static: path.resolve(__dirname, 'public')
        },
        stats: {
            // 开发预览隐藏 [big] 体积标记，与关闭体积告警保持一致
            performance: isProduction
        },
        performance: {
            // three.js 预览工坊允许更大体积（three 核心 min 约 500KB+），保留告警防止意外膨胀
            hints: isProduction ? 'warning' : false,
            maxAssetSize: 1500000,
            maxEntrypointSize: 1800000
        }
    };
};
