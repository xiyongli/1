module.exports = {
    plugins: [
        require('postcss-pxtorem')({
            rootValue: 100,
            propList: ['*'],
            minPixelValue: 2,
            // 预览工坊按固定设计稿 px + transform 缩放实现，不做 px 转 rem
            exclude: /motion_playground/
        }),
        require('autoprefixer')
    ]
};
