# 月卡积分脚手架 — 移动端 H5 动效工坊

开发**可迁移到移动端 H5** 的 UI 组件与动效的独立工作区。只做动效本身：不含业务页面、接口、登录、埋点、MobX Store、Native Bridge 或环境密钥。

技术栈：React 16 · TypeScript（strict）· Webpack 5 · SCSS Modules · PostCSS · Three.js 0.185.1

## 快速开始

环境要求：Node ≥ 18、npm ≥ 9（`package-lock.json` 为 lockfileVersion 3，低版本 npm 会忽略 lockfile 重装依赖，可能装出版本漂移）。

```bash
npm install
npm run dev       # 开发预览：http://127.0.0.1:3023（启动前自动清理端口残留进程）
npm run check     # 交付前全量检查：typecheck + eslint + 动效约束检查 + 生产构建
npm run preview   # 产出单文件 preview/index.html（无外链资源，可直接发人）
npm run package -- --demo <id>   # 交付打包：剔除调试件、附效果基准与接入说明，产出 dist-packages/<id>-delivery-<日期>.zip（SOP 见 docs/delivery-guide.md）
npm run package-repo            # 设计师整仓包：工作区全部源码压 zip（排除 .git / .gitignore / node_modules / 构建产物），产出 dist-packages/<目录名>-<日期>.zip
```

## 页面结构（hash 路由）

| 路由                          | 内容                                                                   |
| ----------------------------- | ---------------------------------------------------------------------- |
| `#/`                          | 动效列表页                                                             |
| `#/motion/<motion-id>`        | 动效工坊：左真机模拟（375×812 机型框 + iOS 状态栏）+ 右调参面板        |
| `#/motion/<motion-id>?full=1` | 全屏展示：无外框无面板，视口流式自适应（分享链接直达，手机打开边到边） |

## 目录结构

```
src/
├── motion_playground/
│   ├── index.tsx              # hash 路由分发
│   ├── home.tsx               # 动效列表页
│   ├── MOTION_RULES.md        # 动效实现规范（A–G 七组，交付硬约束）
│   ├── preview-kit/           # 预览工坊 UI（PreviewWorkshop / PhoneFrame / DockPanel / 控件原子件）
│   └── demos/
│       ├── registry.ts        # 动效注册表（唯一登记入口）
│       └── <motion-id>/      # 一个动效一个子目录（kebab-case）
│           ├── index.tsx            # 动效场景：按 375×812 设计稿铺满手机屏，只写动效本身
│           ├── index.module.scss    # 场景样式
│           ├── workshop.tsx         # 工坊组件：组装 PreviewWorkshop（必须 default export）
│           ├── workshop.module.scss # 工坊主题覆盖（状态栏前景色、页面底色等）
│           ├── assets/              # 本动效专属素材（设计提供的图片放这里，必须被 import）
│           └── …/                   # 复杂动效的分层子目录（见下）
├── shared/                    # 跨 demo 复用层（ddgyPlayer 统一出口、BgImage）
├── hooks/                     # 通用 Hook（useHashPath / useInterval / useLatest）
└── utils/                     # 通用工具（setupRem / setupStageFit）
scripts/                       # 端口清理 / 动效约束检查（check-motion-rules.mjs）
skills/                        # 动效技能说明（ddgy-player-motion/SKILL.md、threejs/SKILL.md）
```

## 新增一个动效（三步）

1. **建目录**：`src/motion_playground/demos/<motion-id>/`（kebab-case）；设计师提供的图片等素材统一放在**本动效自己的 `assets/` 目录**下并通过 import 引用——一动效一套素材，禁止混放公共目录或借用其他动效的资源。
2. **写场景与工坊**：
   - `index.tsx` 场景组件：按 375×812 设计稿铺满手机屏，只写动效本身；对外暴露 `reduced` 等降级 props；
   - `workshop.tsx`：组装 `PreviewWorkshop`（左场景 + 右调参面板），**必须 default export**（React.lazy 懒加载约定）。
3. **登记**：`demos/registry.ts` 追加一条（id / 标题 / 说明 / tags / lazy 组件），路由 `#/motion/<motion-id>` 即自动可达；未访问的动效不进首屏 bundle。

最小骨架：

```tsx
// index.tsx —— 场景：只写动效本身
export function MyMotion({
  reduced = false,
}: {
  reduced?: boolean;
}): JSX.Element {
  return <div className={styles.scene}>…</div>;
}

// workshop.tsx —— 工坊：左场景 + 右调参面板，default export
export default function MyMotionWorkshop(): JSX.Element {
  const [reduced, setReduced] = useState(false);
  return (
    <PreviewWorkshop
      phone={<MyMotion reduced={reduced} />}
      dockTitle="ANIM · MY MOTION"
      dockChildren={/* 调参控件：DockGroup / DockNote / ChipRow / DockSlider … */}
    />
  );
}
```

复杂动效参考分层：`carousel/`（config 配置单源 / math 纯函数 / gesture 手势 / renderer 渲染 / carousel 编排）、`sheet/`（面板子系统）。装配层组件化、行为 Hook 化、命令式核心薄壳化（MOTION_RULES F 组）。

**尺寸与单位约定**：`motion_playground` 目录已排除 px 转 rem（见 `postcss.config.js`），场景与工坊一律直写设计稿 px，由机型框统一 `transform: scale()` 缩放适配视口，不要在 demo 里做 rem 换算。

## 预览工坊（preview-kit）

- `PreviewWorkshop`：左机型框 + 右调参面板开箱组合；机型尺寸可切换（375×812 / 375×667 等，workshop 内自备 `PHONE_DEVICES` 表）
- 控件原子件：`DockSegment` / `DockTabs` / `DockGroup` / `DockNote` / `ChipRow` / `DockSlider`；新调试控件在 preview-kit 扩展，不混进 `demos/`
- 全屏展示：右上浮钮或 `?full=1` 进入，Esc / 常驻 ✕ 退出；场景须按容器尺寸自适应（流式契约）
- Props、主题变量与缩放机制详见 `preview-kit/README.md`

## 设计师整仓包（package-repo）

把整个工程源码打成 zip 发给设计师，设计师本地解压即可预览全部动效并使用预览工坊调参：

```bash
npm run package-repo
```

- 产物：`dist-packages/<目录名>-<日期>.zip`（如 `月卡积分脚手架-20261126.zip`），zip 内含顶层目录，解压不会散开
- 打包内容：工作区当前状态的全部源码与配置（src / public / scripts / skills / docs / 根配置与文档）
- 自动排除：`.git`、`.gitignore`、`node_modules`、`dist`、`preview`、`dist-packages`、`.codex`、`.DS_Store`、`*.log`、`.env*`（密钥不入包）
- 设计师使用：解压 → `npm install` → `npm run dev` → 浏览器打开 `http://127.0.0.1:3023`
- 与 `npm run package -- --demo <id>` 的区别：后者是给研发的单动效交付包（剔调试件、附效果基准与接入说明），本命令是给设计师的完整工程包

## 动效实现规范（MOTION_RULES.md）

实现前先读 `src/motion_playground/MOTION_RULES.md`（A–G 七组，每条对应真实踩坑）。

## 禁止事项

不添加接口、登录、埋点、MobX Store、Native Bridge 或环境密钥；不引入业务代码或业务内部包；不把内部代码推到外部托管平台。

## AI Agent 上手路径

按以下顺序阅读即可独立开发一个新动效：

1. `AGENTS.md`（工程规则）→ 本文档 → `src/motion_playground/MOTION_RULES.md`（实现硬约束）
2. `demos/registry.ts`（登记约定）与上文的最小骨架
3. 需要预览工坊能力查 `preview-kit/README.md`；需要 DdgyPlayer 读 `skills/ddgy-player-motion/SKILL.md`；需要 Three.js 读 `skills/threejs/SKILL.md`（按其映射表加载 `references/`）
4. 实现 → `npm run check` 全过 → 交付时说明：实现方式、资源体积、降级策略、真机验证建议（含低电量模式）
