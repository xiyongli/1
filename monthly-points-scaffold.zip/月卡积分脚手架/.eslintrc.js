module.exports = {
    root: true,
    env: { browser: true, es2021: true, node: true },
    parser: '@typescript-eslint/parser',
    parserOptions: { ecmaVersion: 2021, sourceType: 'module', ecmaFeatures: { jsx: true } },
    plugins: ['@typescript-eslint', 'react-hooks'],
    extends: ['eslint:recommended', 'plugin:@typescript-eslint/recommended'],
    rules: {
        '@typescript-eslint/no-explicit-any': 'error',
        '@typescript-eslint/no-unused-vars': [
            'warn',
            { argsIgnorePattern: '^_', varsIgnorePattern: '^_', caughtErrorsIgnorePattern: '^_' }
        ],
        'react-hooks/rules-of-hooks': 'error',
        'react-hooks/exhaustive-deps': 'error'
    },
    overrides: [
        {
            files: ['*.js'],
            rules: { '@typescript-eslint/no-var-requires': 'off' }
        },
        {
            // vendored 第三方代码：保持原包实现原样，不套用本工程 lint 规则
            files: ['src/shared/ddgyPlayer/vendor/**'],
            rules: {
                '@typescript-eslint/no-explicit-any': 'off',
                '@typescript-eslint/no-non-null-assertion': 'off',
                '@typescript-eslint/ban-ts-comment': 'off',
                '@typescript-eslint/ban-types': 'off',
                '@typescript-eslint/no-empty-function': 'off',
                '@typescript-eslint/no-unused-vars': 'off',
                'react-hooks/exhaustive-deps': 'off'
            }
        },
        {
            // 保留共享视频组件的迁移兼容规则。
            files: ['src/shared/Video/index.tsx'],
            rules: {
                '@typescript-eslint/no-empty-function': 'off',
                '@typescript-eslint/no-inferrable-types': 'off',
                '@typescript-eslint/no-unused-vars': 'off',
                '@typescript-eslint/no-non-null-assertion': 'off',
                '@typescript-eslint/ban-ts-comment': 'off',
                'react-hooks/exhaustive-deps': 'off'
            }
        }
    ],
    ignorePatterns: ['dist/', 'node_modules/']
};
