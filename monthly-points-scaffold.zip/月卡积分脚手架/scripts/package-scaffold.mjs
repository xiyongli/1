/**
 * 月卡积分脚手架整仓打包 —— 完整工程 zip，输出到 dist/。
 *
 * 打包内容：仓库工作区当前状态的全部源码与配置（src / public / scripts / skills / docs /
 * 根配置与文档），zip 内含顶层目录包裹，解压后 npm install && npm run dev 即可预览全部动效。
 * 排除内容与公共流程见 pack-workspace.mjs（.git / .gitignore / node_modules / dist / preview /
 * dist-packages / .codex / .DS_Store / *.log / .env*）。
 * 产物输出：dist/月卡积分脚手架-<日期YYYYMMDD>.zip（dist 已 gitignore，不进仓库）。
 */
import path from "node:path";
import { fileURLToPath } from "node:url";

import { packWorkspace } from "./pack-workspace.mjs";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const stamp = new Date().toISOString().slice(0, 10).replace(/-/g, "");

packWorkspace({
    root,
    outDir: path.join(root, "dist"),
    packageName: `月卡积分脚手架-${stamp}`,
    doneLabel: "月卡积分脚手架整仓包已生成",
    nextStep: "解压后 npm install && npm run dev 即可预览全部动效。"
});
