/**
 * dev 启动器：端口被占用时自动 +1 重试（3023 → 3024 → ...）。
 *
 * 职责范围：
 * - 探测 127.0.0.1 上从 3023 起的端口，找到第一个可用端口
 * - 用该端口拉起 webpack-dev-server（等价于 webpack serve --mode development）
 * - 透传额外 CLI 参数，例如 `npm run dev -- --no-open`
 */
import net from "node:net";
import path from "node:path";
import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

/** 与 webpack.config.js 中 devServer 的 host / port 保持一致 */
const HOST = "127.0.0.1";
const BASE_PORT = 3023;
/** 最多尝试 BASE_PORT ~ BASE_PORT + 9 */
const MAX_ATTEMPTS = 10;

/** 探测端口是否可绑定（与 devServer 实际监听行为一致，绑定后立即释放） */
function isPortFree(port) {
    return new Promise((resolve) => {
        const server = net.createServer();
        server.once("error", () => resolve(false));
        server.once("listening", () => server.close(() => resolve(true)));
        server.listen(port, HOST);
    });
}

/** 从 BASE_PORT 开始逐个 +1，返回第一个可用端口 */
async function pickPort() {
    for (let i = 0; i < MAX_ATTEMPTS; i += 1) {
        const port = BASE_PORT + i;
        // eslint-disable-next-line no-await-in-loop
        if (await isPortFree(port)) {
            return port;
        }
        console.log(`[dev] 端口 ${port} 被占用，自动尝试 ${port + 1} ...`);
    }
    throw new Error(`[dev] ${BASE_PORT}~${BASE_PORT + MAX_ATTEMPTS - 1} 均被占用，请先释放端口`);
}

const port = await pickPort();
const webpackBin = path.resolve(__dirname, "../node_modules/webpack/bin/webpack.js");
const forwardArgs = process.argv.slice(2);

const child = spawn(
    process.execPath,
    [webpackBin, "serve", "--mode", "development", "--port", String(port), ...forwardArgs],
    { stdio: "inherit" }
);

/** Ctrl+C / kill 时同步终止子进程，避免残留 dev server 占用端口 */
for (const signal of ["SIGINT", "SIGTERM"]) {
    process.on(signal, () => child.kill(signal));
}

child.on("error", (err) => {
    console.error("[dev] 启动 webpack-dev-server 失败:", err);
    process.exit(1);
});

child.on("exit", (code) => {
    process.exit(code ?? 0);
});
