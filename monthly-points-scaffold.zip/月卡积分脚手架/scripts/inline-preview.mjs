/**
 * preview 产物内联脚本：把 webpack 构建结果压缩成单个 HTML 文件。
 *
 * 职责范围：
 * - 将 <script src> 引用的本地 JS 内联进 HTML
 * - 将 <link rel="stylesheet"> 引用的本地 CSS 内联进 HTML（当前构建用 style-loader，此分支为兜底）
 * - 删除 assets 目录，保证 preview/ 下只有一个 index.html
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const previewDir = path.resolve(__dirname, "../preview");
const htmlPath = path.join(previewDir, "index.html");

let html = fs.readFileSync(htmlPath, "utf8");

/** 读取相对 preview/index.html 的本地资源文件 */
const readAsset = (src) => fs.readFileSync(path.join(previewDir, src), "utf8");

/**
 * 内联 JS 需转义会提前终止 script 解析的序列；
 * `\/` 与 `\!` 在 JS 的字符串、模板字符串、正则中求值结果均不变，属于安全转义
 */
const escapeInlineJs = (code) =>
    code.replace(/<\/script/gi, "<\\/script").replace(/<!--/g, "<\\!--");

// 内联外链 script：从原位置移除，统一插到 </body> 前。
// 原因：内联 script 会忽略 defer 属性，若留在 head 中会在 #root 解析前执行导致渲染失败
const inlineScripts = [];
html = html.replace(/<script\b[^>]*\bsrc="([^"]+)"[^>]*><\/script>/gi, (tag, src) => {
    console.log(`[preview] 内联脚本: ${src}`);
    inlineScripts.push(escapeInlineJs(readAsset(src)));
    return "";
});

// 在 </body> 前插入内联脚本，保证执行时 #root 等 DOM 已解析完成
html = html.replace(/<\/body>/i, () => `${inlineScripts.map((code) => `<script>${code}</script>`).join("")}</body>`);

// 内联外链样式（兜底，非 stylesheet 的 link 标签保持原样）
html = html.replace(/<link\b[^>]*\bhref="([^"]+)"[^>]*>/gi, (tag, href) => {
    if (!/rel="stylesheet"/i.test(tag)) {
        return tag;
    }
    console.log(`[preview] 内联样式: ${href}`);
    return `<style>${readAsset(href)}</style>`;
});

fs.writeFileSync(htmlPath, html);

// 删除 assets 目录，保证单文件产物
fs.rmSync(path.join(previewDir, "assets"), { recursive: true, force: true });

const sizeKiB = (fs.statSync(htmlPath).size / 1024).toFixed(1);
console.log(`预览文件已生成: preview/index.html（单文件, ${sizeKiB} KiB, 双击即可打开）`);
