import net from 'node:net';
import { execSync } from 'node:child_process';

import webpackConfig from '../webpack.config.js';

/** 等待端口释放的最长时间 */
const WaitForFreeTimeoutMs = 3000;
/** 释放确认的轮询间隔 */
const PollIntervalMs = 100;

/** 端口取值优先级：命令行参数 > webpack devServer 配置 > 3023 */
const port = Number(process.argv[2]) || webpackConfig.devServer?.port || 3023;

/** 探测端口是否空闲：能成功监听即空闲 */
function isPortFree(portNumber) {
    return new Promise((resolve) => {
        const server = net.createServer();
        server.once('error', () => resolve(false));
        server.once('listening', () => server.close(() => resolve(true)));
        server.listen(portNumber, '127.0.0.1');
    });
}

/** 查找占用端口的进程 PID：darwin/linux 用 lsof，win32 用 netstat */
function findOccupantPids(portNumber) {
    try {
        if (process.platform === 'win32') {
            const output = execSync('netstat -ano -p tcp', { encoding: 'utf8' });
            return [...output.matchAll(/TCP\s+\S+:(\d+)\s+\S+\s+LISTENING\s+(\d+)/g)]
                .filter((match) => Number(match[1]) === portNumber)
                .map((match) => match[2]);
        }
        const output = execSync(`lsof -ti tcp:${portNumber} -sTCP:LISTEN`, {
            encoding: 'utf8'
        });
        return output
            .split('\n')
            .map((line) => line.trim())
            .filter(Boolean);
    } catch {
        return [];
    }
}

/** 强制结束占用进程；进程已自行退出时忽略 */
function killOccupantPids(pids) {
    for (const pid of pids) {
        try {
            process.kill(Number(pid), 'SIGKILL');
            console.log(`已结束占用进程 PID ${pid}`);
        } catch {
            console.warn(`PID ${pid} 已不存在，跳过`);
        }
    }
}

/** 轮询等待端口释放 */
async function waitForPortFree(portNumber) {
    const deadline = Date.now() + WaitForFreeTimeoutMs;
    while (Date.now() < deadline) {
        if (await isPortFree(portNumber)) return true;
        await new Promise((resolve) => setTimeout(resolve, PollIntervalMs));
    }
    return isPortFree(portNumber);
}

if (await isPortFree(port)) {
    console.log(`端口 ${port} 空闲，无需清理。`);
    process.exit(0);
}

console.log(`端口 ${port} 被占用，正在清理…`);
const occupantPids = findOccupantPids(port);
if (occupantPids.length === 0) {
    console.error(`未找到占用端口 ${port} 的进程，请手动排查。`);
    process.exit(1);
}

killOccupantPids(occupantPids);

if (await waitForPortFree(port)) {
    console.log(`端口 ${port} 已释放。`);
    process.exit(0);
}

console.error(`端口 ${port} 释放失败，请手动处理后重试。`);
process.exit(1);
