/**
 * 整仓打包公共流程（package-repo / package-scaffold 共用）：
 * rsync 拷贝工作区（排除产物清单见下）→ 统计规模 → 压 zip（顶层目录包裹，解压不散开）→ 清理暂存。
 *
 * 排除内容：.git / .gitignore / node_modules / dist / preview / dist-packages /
 * .codex 工具缓存 / .DS_Store / *.log / .env*（密钥不入包）。
 * 注意：outDir 必须位于排除清单内（暂存目录建在 outDir 下，避免 rsync 递归拷贝自身）。
 */
import { execSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";

const EXCLUDES = [".git", ".gitignore", "node_modules", "dist", "preview", "dist-packages", ".codex", ".DS_Store", "*.log", ".env*"];

const walk = (dir, fn) => {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
        const p = path.join(dir, entry.name);
        if (entry.isDirectory()) walk(p, fn);
        else fn(p);
    }
};

const fmtBytes = n => (n >= 1024 * 1024 ? `${(n / 1024 / 1024).toFixed(1)}MB` : `${Math.max(1, Math.round(n / 1024))}KB`);

/**
 * 打整仓 zip。packageName 同时作为 zip 文件名与包内顶层目录名（含日期后缀由调用方拼好）。
 * 返回 zip 绝对路径。
 */
export function packWorkspace({ root, outDir, packageName, doneLabel, nextStep }) {
    fs.mkdirSync(outDir, { recursive: true });
    const stage = path.join(outDir, packageName);
    fs.rmSync(stage, { recursive: true, force: true });

    console.log("[1/3] 拷贝工作区源码…");
    execSync(`rsync -a ${EXCLUDES.map(e => `--exclude=${e}`).join(" ")} ${root}/ ${stage}/`);

    let fileCount = 0;
    let totalBytes = 0;
    walk(stage, p => {
        fileCount += 1;
        totalBytes += fs.statSync(p).size;
    });
    console.log(`[2/3] 共 ${fileCount} 个文件 / ${fmtBytes(totalBytes)}，开始压缩…`);

    execSync(`zip -r -q -X "${packageName}.zip" "${packageName}"`, { cwd: outDir });
    fs.rmSync(stage, { recursive: true, force: true });

    const zipPath = path.join(outDir, `${packageName}.zip`);
    console.log(`
✅ ${doneLabel}：${path.relative(root, zipPath)}（${fmtBytes(fs.statSync(zipPath).size)}）
   源码 ${fileCount} 文件 / ${fmtBytes(totalBytes)}（不含 node_modules 与构建产物）
📦 下一步：${nextStep}`);
    return zipPath;
}
