import { readFile, readdir, stat } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ScriptDirectory = path.dirname(fileURLToPath(import.meta.url));
const ProjectDirectory = path.resolve(ScriptDirectory, '..');
const SourceDirectory = path.join(ProjectDirectory, 'src');
const DemosDirectory = path.join(SourceDirectory, 'motion_playground', 'demos');
const SourceExtensions = new Set(['.ts', '.tsx', '.scss', '.html']);
const DemoCodeExtensions = new Set(['.ts', '.tsx', '.scss', '.css']);
const MediaExtensions = new Set(['.png', '.jpg', '.jpeg', '.webp', '.avif', '.gif']);

async function collectFiles(directory, extensions) {
    const directoryEntries = await readdir(directory, { withFileTypes: true });
    const nestedFiles = await Promise.all(
        directoryEntries.map(entry => {
            const entryPath = path.join(directory, entry.name);
            return entry.isDirectory() ? collectFiles(entryPath, extensions) : [entryPath];
        })
    );
    return nestedFiles.flat().filter(filePath => extensions.has(path.extname(filePath)));
}

const sourceFiles = await collectFiles(SourceDirectory, SourceExtensions);
const demoCodeFiles = await collectFiles(DemosDirectory, DemoCodeExtensions);
const demoMediaFiles = await collectFiles(DemosDirectory, MediaExtensions);

let canvasCount = 0;
const violations = [];
const prompts = [];

for (const sourceFile of sourceFiles) {
    const sourceText = await readFile(sourceFile, 'utf8');
    const relativePath = path.relative(ProjectDirectory, sourceFile);
    canvasCount += (sourceText.match(/<canvas\b/gi) || []).length;

    if (/<animate(?:Motion|Transform)?\b/i.test(sourceText)) violations.push(`${relativePath}: 禁止 SVG 动画`);
    if (/dangerouslySetInnerHTML/.test(sourceText)) violations.push(`${relativePath}: 禁止直接注入 HTML`);
    if (/\b(?:fetch|axios)\s*(?:\.|\()/.test(sourceText)) violations.push(`${relativePath}: Demo 不应包含业务接口`);
}

// ===== 提示类检查（性能基准 Canvas / MOTION_RULES.md【脚本·提示】条款）=====
// 不强制、不影响退出码：命中仅提示低端机影响与替代方案，由用户决策是否接受或降级。

// 性能基准：Canvas 数量越少越好（多场景复用同一 Canvas），超 1 个仅提示不阻断
if (canvasCount > 1) prompts.push(`[Canvas] Canvas 数量为 ${canvasCount}（性能基准要求越少越好：转场动效优先用多场景思路复用同一个 Canvas，如果不满足要求才新增；引入 Canvas 后其余动画尽量同栈实现）（不强制）`);

// 被 import 的媒体引用（D2 只检查实际进 bundle 的文件，未引用文件属 D1 死资源范畴）
const importedMediaReferences = new Set();

for (const demoFile of demoCodeFiles) {
    const sourceText = await readFile(demoFile, 'utf8');
    const relativePath = path.relative(ProjectDirectory, demoFile);

    for (const match of sourceText.matchAll(/media\/[\w./-]+\.(?:png|jpe?g|webp|avif|gif)/gi)) {
        importedMediaReferences.add(match[0].toLowerCase());
    }

    // C1：blur 调用点。blur 可能直接写在 CSS（filter: blur(...)），也可能由 JS 写入
    // CSS 变量再消费（filter: var(--x)），故统一扫描 blur( 并跳过注释行。
    const blurLines = sourceText.split('\n').filter(line => {
        const trimmed = line.trim();
        return !/^(?:\/\/|\/\*|\*|<!--)/.test(trimmed) && /blur\s*\(/i.test(trimmed);
    });
    if (blurLines.length > 0) {
        prompts.push(`${relativePath}: [C1] 检测到 ${blurLines.length} 处 blur() 调用（含经 CSS 变量消费的动态模糊），低端机可能掉帧；建议预烘焙序列图/渐变遮罩/静态 blur 替代（不强制）`);
    }

    // C1：box-shadow 过渡动画
    if (/transition[^;{}]*box-shadow/i.test(sourceText)) {
        prompts.push(`${relativePath}: [C1] 检测到 box-shadow 过渡动画，低端机易掉帧；建议 opacity/预烘焙替代（不强制）`);
    }

    // 性能基准：left/top 布局属性过渡（触发重排，建议改用 transform）
    if (/transition[^;{}]*(?<![\w-])(?:left|top)\b/i.test(sourceText)) {
        prompts.push(`${relativePath}: [性能基准] 检测到 left/top 布局属性过渡，触发重排；建议改用 transform 实现位移（不强制）`);
    }
}

// D2：图片体积与格式（解码位图内存远大于文件体积）
for (const mediaFile of demoMediaFiles) {
    const relativeToDemos = path.relative(DemosDirectory, mediaFile).replace(/\\/g, '/').toLowerCase();
    if (![...importedMediaReferences].some(reference => relativeToDemos.endsWith(reference))) continue;

    const { size } = await stat(mediaFile);
    const relativePath = path.relative(ProjectDirectory, mediaFile);
    const extension = path.extname(mediaFile).toLowerCase();
    if (size > 500 * 1024) {
        prompts.push(`${relativePath}: [D2] ${Math.round(size / 1024)}KB 大图，建议分段/懒解码并转 WebP（不强制）`);
    } else if (size > 100 * 1024 && extension !== '.webp' && extension !== '.avif') {
        prompts.push(`${relativePath}: [D2] ${Math.round(size / 1024)}KB 非 WebP/AVIF，建议转换格式（不强制）`);
    }
}

if (prompts.length > 0) {
    console.warn(`\n[动效提示] ${prompts.length} 条命中提示类条款（性能基准 / MOTION_RULES.md，不强制、不阻断交付），请评估低端机影响与替代方案：`);
    console.warn(prompts.join('\n'));
}

if (violations.length > 0) {
    console.error(violations.join('\n'));
    process.exitCode = 1;
} else {
    console.log(`动效规则检查通过：Canvas ${canvasCount} 个（越少越好），未发现 SVG 动画、HTML 注入或接口调用${prompts.length > 0 ? `；${prompts.length} 条提示见上` : ''}。`);
}
