#!/usr/bin/env node
/**
 * 动效交付打包器 —— 标准化交付流程（SOP 见 docs/delivery-guide.md）。
 *
 * 用法：npm run package -- --demo <motion-id>
 *
 * 做五件事：
 * 1. 拷贝 demo 目录为交付暂存，剔除调试件（workshop.tsx / workshop.module.scss）与过程文档（*.md）；
 * 2. 依赖边界扫描：@shared / @hooks / @utils 与越出 demo 目录的 import 会被警告并写入 DELIVERY.md；
 * 3. 统计代码与媒体规模、解析 registry 元信息、收集外部依赖版本；
 * 4. npm run preview 产出效果基准，拷为 preview-baseline.html；
 * 5. 生成 DELIVERY.md（内联 demo 的 delivery.md 接入说明）并压 zip 到 dist-packages/（已 gitignore）。
 */
import { execSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";

const args = process.argv.slice(2);
const argValue = (name) => {
  const i = args.indexOf(`--${name}`);
  return i >= 0 ? args[i + 1] : undefined;
};

const demoId = argValue("demo");
if (!demoId) {
  console.error("用法：npm run package -- --demo <motion-id>");
  process.exit(1);
}

const root = process.cwd();
const srcDir = path.join(root, "src/motion_playground/demos", demoId);
if (!fs.existsSync(srcDir)) {
  console.error(`未找到动效目录：src/motion_playground/demos/${demoId}`);
  process.exit(1);
}

const outDir = path.join(root, "dist-packages");
const stageName = `${demoId}-delivery`;
const stage = path.join(outDir, stageName);
fs.rmSync(stage, { recursive: true, force: true });
fs.mkdirSync(stage, { recursive: true });

const MEDIA_EXT = new Set([".png", ".jpg", ".jpeg", ".webp", ".avif", ".gif", ".svg", ".mp3", ".mp4", ".ogg", ".wav"]);
const CODE_EXT = new Set([".ts", ".tsx", ".js", ".jsx", ".css", ".scss"]);

const walk = (dir, fn) => {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(p, fn);
    else fn(p);
  }
};

const fmtBytes = (n) => (n >= 1024 * 1024 ? `${(n / 1024 / 1024).toFixed(1)}MB` : `${Math.max(1, Math.round(n / 1024))}KB`);

// 1. 拷贝并剔除调试件与过程文档（delivery.md 不直接拷贝，内联进 DELIVERY.md）
console.log(`[1/4] 拷贝 ${demoId} 并剔除调试件…`);
walk(srcDir, (file) => {
  const rel = path.relative(srcDir, file);
  const base = path.basename(rel);
  if (base === "workshop.tsx" || base === "workshop.module.scss") return;
  if (base.endsWith(".md")) return;
  const dest = path.join(stage, rel);
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  fs.copyFileSync(file, dest);
});

// 2. 依赖边界扫描 + 3. 规模统计
console.log("[2/4] 依赖边界扫描与规模统计…");
const externalDeps = new Set();
const boundaryHits = [];
let codeFiles = 0;
let codeLines = 0;
let mediaFiles = 0;
let mediaBytes = 0;

walk(stage, (file) => {
  const ext = path.extname(file).toLowerCase();
  if (MEDIA_EXT.has(ext)) {
    mediaFiles += 1;
    mediaBytes += fs.statSync(file).size;
    return;
  }
  if (!CODE_EXT.has(ext)) return;
  codeFiles += 1;
  const text = fs.readFileSync(file, "utf8");
  codeLines += text.split("\n").length;
  if (ext !== ".ts" && ext !== ".tsx") return;
  for (const m of text.matchAll(/(?:from|import)\s+["']([^"']+)["']/g)) {
    const spec = m[1];
    if (spec.startsWith(".")) {
      const resolved = path.resolve(path.dirname(file), spec);
      if (!resolved.startsWith(stage + path.sep) && resolved !== stage) {
        boundaryHits.push(`- \`${path.relative(stage, file)}\` → \`${spec}\`（越出 demo 目录，需随包附带对应模块）`);
      }
    } else if (spec.startsWith("@")) {
      boundaryHits.push(`- \`${path.relative(stage, file)}\` → \`${spec}\`（公共层依赖，需随包附带）`);
    } else {
      externalDeps.add(spec);
    }
  }
});

// registry 元信息
const registryRaw = fs.readFileSync(path.join(root, "src/motion_playground/demos/registry.ts"), "utf8");
const idx = registryRaw.indexOf(`id: "${demoId}"`);
const win = registryRaw.slice(idx >= 0 ? idx : 0, (idx >= 0 ? idx : 0) + 1200);
const title = win.match(/title:\s*"([^"]*)"/)?.[1] ?? demoId;
const description = win.match(/description:\s*[\s]*"([^"]*)"/)?.[1] ?? "";
const tags = [...(win.match(/tags:\s*\[([^\]]*)\]/)?.[1] ?? "").matchAll(/"([^"]+)"/g)].map((m) => m[1]);

// 外部依赖版本（从根 package.json 查）
const pkg = JSON.parse(fs.readFileSync(path.join(root, "package.json"), "utf8"));
const depVersion = (name) => pkg.dependencies?.[name] ?? pkg.devDependencies?.[name] ?? "未在 package.json 声明";

// 4. 效果基准
console.log("[3/4] 构建效果基准（npm run preview）…");
execSync("npm run preview", { stdio: "inherit", cwd: root });
const baseline = path.join(root, "preview", "index.html");
if (!fs.existsSync(baseline)) {
  console.error("preview/index.html 未生成，打包中止");
  process.exit(1);
}
fs.copyFileSync(baseline, path.join(stage, "preview-baseline.html"));

// 5. 生成 DELIVERY.md
const deliveryNotesPath = path.join(srcDir, "delivery.md");
const deliveryNotes = fs.existsSync(deliveryNotesPath)
  ? fs.readFileSync(deliveryNotesPath, "utf8")
  : "> ⚠️ demo 目录缺 `delivery.md` 接入说明，请补写后重新打包。";

const now = new Date();
const stamp = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, "0")}${String(now.getDate()).padStart(2, "0")}`;
const depList = [...externalDeps].sort().map((d) => `- \`${d}@${depVersion(d)}\``).join("\n") || "- 无";

const deliveryMd = `# ${title} 交付包（${demoId}）

> 由 \`npm run package -- --demo ${demoId}\` 生成于 ${stamp}。交付标准见 docs/delivery-guide.md。
> 效果验收金标准：\`preview-baseline.html\`（双击打开即看）。

- 说明：${description}
- 实现方式：${tags.join(" / ") || "未标注"}

## 包内容

- 动效源码：${codeFiles} 个代码文件 / ${codeLines} 行（已剔除 workshop 调试壳与过程文档）
- 媒体资源：${mediaFiles} 个 / ${fmtBytes(mediaBytes)}（import 即依赖，无死资源）
- 效果基准：preview-baseline.html

## 运行依赖

${depList}

${boundaryHits.length ? `## ⚠️ 依赖边界警告（需人工确认）\n\n${boundaryHits.join("\n")}\n` : ""}
## 接入说明

${deliveryNotes}
`;

fs.writeFileSync(path.join(stage, "DELIVERY.md"), deliveryMd);

// 压 zip
console.log("[4/4] 压缩交付包…");
const zipName = `${demoId}-delivery-${stamp}.zip`;
execSync(`zip -r -q -X ${zipName} ${stageName}`, { cwd: outDir });
const zipPath = path.join(outDir, zipName);
const zipSize = fmtBytes(fs.statSync(zipPath).size);

console.log(`
✅ 交付包已生成：${path.relative(root, zipPath)}（${zipSize}）
   源码 ${codeFiles} 文件 / ${codeLines} 行 · 媒体 ${mediaFiles} 个 / ${fmtBytes(mediaBytes)}${boundaryHits.length ? `\n⚠️ 依赖边界警告 ${boundaryHits.length} 条，已写入 DELIVERY.md，请人工确认` : ""}
📦 下一步（见 docs/delivery-guide.md）：上传 Artifacts 网盘 → 创建分享链接 → 发研发，验收以 preview-baseline.html 为金标准。`);
