import { defineConfig } from 'windicss/helpers';
import lineClampPlugin from 'windicss/plugin/line-clamp';

// 显式文件导入（目录导入在部分加载器下不可解析）
import plugins from './windi/windicss-plugins/index';

export default defineConfig({
    preflight: false,
    extract: {
        include: ['./src/**/*.{jsx,tsx,ts}']
    },
    shortcuts: {
        'ab-xy': {
            position: 'absolute',
            left: '50%',
            top: '50%',
            transform: 'translate(-50%, -50%) scale(1)'
        },
        'ab-x': {
            position: 'absolute',
            left: '50%',
            transform: 'translateX(-50%) scale(1)'
        },
        'ab-y': {
            position: 'absolute',
            top: '50%',
            transform: 'translateY(-50%) scale(1)'
        },
        'ab-xy-full': 'ab-xy w-full h-full',
        'ab-0-auto': 'absolute left-0 right-0 mx-auto',
        'ab-x-nowrap': 'abs-x-center whitespace-nowrap',
        'fl-xy': 'flex justify-center items-center',
        'flc-xy': 'flex flex-col justify-center items-center',
        'flc-y': 'flex flex-col justify-center',
        'fl-x': 'flex justify-center',
        'fl-b': 'flex justify-between',
        'fl-y': 'flex items-center',
        'fl-y-b': 'flex items-center justify-between',
        'ff-s': 'pfs font-600',
        'ff-shuHei': {
            'font-family': 'ShuHeiFont'
        },
        // 字体切片，每个都有全量文字
        'ff-yuanhei': {
            'font-family': 'Font-MF-YuanHei'
        },
        'ff-meijia': {
            'font-family': 'Font-MF-MeiJia'
        },
        'ff-puhui-heavy': {
            'font-family': 'Aibaba-PuHuiTi-Heavy'
        },
        'ff-misans-bold': {
            'font-family': 'Font-MiSans-Bold'
        },
        'ff-misans-regular': {
            'font-family': 'Font-MiSans-Regular'
        },
        'w-fit': {
            width: 'fit-content'
        },
        'bg-init': {
            '@apply': 'bg-no-repeat',
            'background-size': '100% 100%'
        }
    },
    plugins: [lineClampPlugin, ...plugins]
});
