import { useEffect, useState } from 'react';

/**
 * 极简 hash 路由：路径约定以 '/' 开头（如 '/'、'/motion/<id>'）。
 * 选择 hash 而非 History API：构建产物静态托管 / file:// 直开均可运行，无需服务端回退配置。
 */

function readHashPath(): string {
    const raw = window.location.hash.replace(/^#/, '');
    return raw.startsWith('/') ? raw : '/';
}

/** 订阅并返回当前 hash 路由路径 */
export function useHashPath(): string {
    const [path, setPath] = useState(readHashPath);

    useEffect(() => {
        const onChange = () => setPath(readHashPath());
        window.addEventListener('hashchange', onChange);
        return () => window.removeEventListener('hashchange', onChange);
    }, []);

    return path;
}

/** 编程式跳转（等价于点击 <a href="#...">） */
export function navigateHash(path: string): void {
    window.location.hash = `#${path}`;
}
