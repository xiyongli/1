import { useRef } from "react";

/** 保存最新值，供定时器等异步回调读取，避免闭包持有旧值。 */
export function useLatest<TValue>(
  value: TValue,
): React.MutableRefObject<TValue> {
  const valueRef = useRef(value);
  valueRef.current = value;
  return valueRef;
}
