import { useEffect } from 'react';

import { useLatest } from './useLatest';

/** 创建可安全清理且始终调用最新回调的定时器。 */
export function useInterval(callback: () => void, delay?: number): void {
    const callbackRef = useLatest(callback);

    useEffect(() => {
        if (typeof delay !== 'number' || delay < 0) return undefined;

        const timerId = window.setInterval(() => callbackRef.current(), delay);
        return () => window.clearInterval(timerId);
    }, [callbackRef, delay]);
}
