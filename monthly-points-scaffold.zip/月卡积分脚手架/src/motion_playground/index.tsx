import React, { Suspense } from 'react';

import { navigateHash, useHashPath } from '@hooks/useHashPath';

import { MOTION_REGISTRY } from './demos/registry';
import { MotionHome } from './home';

import './preview-kit/preview-workshop.css';
import styles from './router.module.scss';

/**
 * 动效工作区入口：hash 路由分发。
 * - '/' → 动效列表页
 * - '/motion/<id>' → 对应动效工坊（registry 懒加载 chunk，未访问不进首屏 bundle）
 * - 其余路径 → 未找到提示
 */
export function MotionPlayground(): JSX.Element {
    const path = useHashPath();
    // 全屏展示参数（?full=1）不参与路由匹配，剥掉后再分发
    const basePath = path.split('?')[0] ?? '/';
    const motionMatch = basePath.match(/^\/motion\/([\w-]+)$/);
    const demo = motionMatch ? MOTION_REGISTRY.find(item => item.id === motionMatch[1]) : undefined;

    if (basePath === '/') {
        return <MotionHome />;
    }

    if (demo) {
        return (
            <>
                <a className={`${styles.back} pw-route-back`} href="#/" aria-label="返回动效列表">
                    ←
                </a>
                <Suspense fallback={<div className={styles.loading}>动效加载中…</div>}>
                    <demo.Component />
                </Suspense>
            </>
        );
    }

    return (
        <div className={styles.missing}>
            <p>未找到动效：{basePath}</p>
            <button type="button" onClick={() => navigateHash('/')}>
                返回列表
            </button>
        </div>
    );
}
