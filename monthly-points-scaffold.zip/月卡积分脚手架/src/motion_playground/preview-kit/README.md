# preview-kit：预览工坊 UI（左机型 + 右面板）

可移植的预览工坊 UI。零外部依赖（仅 React），纯 CSS 主题，整目录拷到目标仓库即可使用。

## 结构

| 文件 | 内容 |
| --- | --- |
| `PreviewWorkshop.tsx` | 开箱即用的组合组件：左机型框 + 右调参面板 |
| `PhoneFrame.tsx` | 机型框（自动缩放、圆角、边框 bezel） |
| `PhoneChrome.tsx` | iOS 状态栏（实时时钟/信号/WiFi/电量 SVG）+ Home 条 |
| `DockPanel.tsx` | 右侧面板壳：标题 + 页面分段 + 分类下划线 Tab + 滚动主体 |
| `dockControls.tsx` | 原子件：`DockSegment` / `DockTabs` / `DockGroup` / `DockNote` / `ChipRow` |
| `preview-workshop.css` | 全部样式（`pw-` 前缀，避免与目标仓库冲突） |

## 快速开始

```tsx
import { useState } from "react";
import { PreviewWorkshop } from "./preview-kit/PreviewWorkshop";
import "./preview-kit/preview-workshop.css";

const TABS = [
  { id: "env", label: "环境" },
  { id: "monthly-points", label: "月卡积分" },
];

export function App() {
  const [tab, setTab] = useState("env");
  return (
    <PreviewWorkshop
      phone={<YourPreviewScene />}            {/* 手机屏内容，按 375×812 设计稿铺满 */}
      dockTitle="预览工坊"
      tabs={TABS}
      activeTab={tab}
      onTabChange={setTab}
      groups={[
        { id: "light", title: "灯光", defaultOpen: true, lead: "主光与补光" },
        { id: "motion", title: "运动" },
      ]}
      renderGroup={(group) => <p>「{group.title}」的控件放这里</p>}
    />
  );
}
```

## Props（PreviewWorkshop）

| 参数 | 类型 | 默认 | 说明 |
| --- | --- | --- | --- |
| `phone` | `ReactNode` | 必填 | 机型屏内容（建议按 `phoneWidth × phoneHeight` 设计稿实现，组件会自动铺满并缩放） |
| `showChrome` | `boolean` | `true` | 是否显示 iOS 状态栏 + Home 条 |
| `phoneWidth` / `phoneHeight` | `number` | `375` / `812` | 机型设计尺寸（CSS px），可换其他机型 |
| `dockWidth` | `number` | `320` | 右侧面板宽 |
| `background` | `string` | — | 页面背景色 |
| `dockTitle` | `string` | — | 面板顶部小标题 |
| `pages` / `activePage` / `onPageChange` | `DockItem[]` / `string` / `(id) => void` | — | L1 页面分段控件（可选） |
| `tabs` / `activeTab` / `onTabChange` | `DockItem[]` / `string` / `(id) => void` | — | L2 分类下划线 Tab |
| `groups` | `{ id, title, lead?, defaultOpen? }[]` | — | 折叠分组（仅标题骨架） |
| `renderGroup` | `(group) => ReactNode` | — | 每组内容插槽；不传显示「待接入控件」占位 |
| `dockChildren` | `ReactNode` | — | 完全自定义面板主体（传入时忽略 `groups`） |
| `className` | `string` | — | 追加到根节点 |

不传 `pages` / `tabs` / `groups` / `dockChildren` 时只渲染机型框，自动去掉右侧空间。

## 原子件单独使用

```tsx
import { PhoneFrame } from "./preview-kit/PhoneFrame";
import { DockPanel } from "./preview-kit/DockPanel";
import { DockGroup, DockNote, ChipRow } from "./preview-kit/dockControls";

<PhoneFrame showChrome={false}>
  <YourScene />
</PhoneFrame>

<DockPanel tabs={TABS} activeTab={tab} onTabChange={setTab}>
  <DockGroup title="灯光" defaultOpen>
    <DockNote>主光方位</DockNote>
    <ChipRow>
      <button className="is-on">左</button>
      <button>右</button>
    </ChipRow>
  </DockGroup>
</DockPanel>
```

`DockGroup` 不传 `open` / `onToggle` 时自管折叠状态，传入即变为受控。

## 缩放机制

`--pw-phone-scale` 由纯 CSS `min()` 计算：机型和面板整体在视口内 `contain`，不溢出、不出现滚动条：

```
scale = min(1, (视口高 - 上下留白) / 机型高, (视口宽 - 左右留白 - 间距 - 面板宽) / 机型宽)
```

外层 `.pw-phone-shell` 按缩放后的尺寸占位，内层 `.pw-phone-frame` 固定设计尺寸后 `transform: scale()`，因此屏内内容可按设计稿绝对坐标实现。

## 全屏展示

右上角「全屏展示」浮钮（或直接打开 `#/motion/<id>?full=1`）进入纯展示模式：机型外框、状态栏、调参面板全部隐藏，机型视口变为浏览器视口（`100dvw × 100dvh`、scale=1、无黑边），仅保留常驻 ✕ 退出浮钮（Esc 同样可退）。

- **URL 双向同步**：进入后地址栏变为 `?full=1`（`history.replaceState`，不产生历史记录），复制即可分享；手机打开分享链接直达全屏，动画按接收方屏幕尺寸流式铺满。
- **phone 节点不 remount**：进出全屏场景状态全保留，转盘/弹簧不重播。
- **自适应契约**：全屏态下机型视口 = 任意尺寸的真实视口，`phone` 场景必须按容器尺寸自适应布局（用 `ResizeObserver` 监听容器、以 `clientWidth/clientHeight` 推导布局，禁止写死 375×812 假设居中）。未适配的固定尺寸场景在全屏下会错位，接入全屏展示前先完成场景流式改造。

## 主题定制

全部走 `.pw-root` 上的 CSS 变量：

| 变量 | 默认 | 说明 |
| --- | --- | --- |
| `--pw-phone-bg` | `#101014` | 机型屏底色 |
| `--pw-bezel-color` | `#1f1f1f` | 边框圈色 |
| `--pw-phone-radius` | `28px` | 屏幕圆角 |
| `--pw-chrome-fg` | `#1c1428` | 状态栏前景色（浅色屏适用） |
| `--pw-dock-bg` / `--pw-dock-surface` / `--pw-dock-surface-raised` | `#131218` / `#1a1920` / `#222128` | 面板三级底色 |
| `--pw-dock-border` | `rgba(255,255,255,.07)` | 面板描边 |
| `--pw-dock-text` / `--pw-dock-text-muted` | — | 面板主/次文字色 |
| `--pw-dock-accent` | `#9b93b0` | 强调色 |
| `--pw-pad-x` / `--pw-pad-y` / `--pw-gap` | `16px` / `12px` / `20px` | 页面留白与机面间距 |

## 后续扩展控件

需要滑杆、开关、数值输入等完整调参控件时，参考源仓库 `demo/dockControls.tsx`（`Slider` / `ToggleRow` / `NumberField` / `SubGroup` / `StepTabs`）与 `demo/Demo.css` 中对应样式，把类名前缀 `bb-demo-` 改为 `pw-` 即可并入本套。
