import { useCallback, useEffect, useRef, useState } from "react";

/**
 * 工坊参数持久化 Hook —— 设计侧「代码动画反复调整问题复盘」六项默认能力的落点之一。
 *
 * 功能范围（仅服务工坊调参面板，不进交付包）：
 * - 自动保存与恢复：参数修改实时生效，防抖落盘；刷新 / 关闭重开 / 路由切换后恢复；
 * - 迭代保留已调值：初始化先读保存值再与默认值浅合并（旧值优先、新字段补缺），
 *   防止"初始化默认值覆盖历史配置"；读取失败回退默认但【不立即写回】；
 * - 快照版本：已确认的调参可存为命名快照，随时恢复；重置恢复默认由用户主动触发；
 * - 保存状态真实可见：保存中 / 已保存 / 失败三态如实上报，localStorage 异常不假称已保存。
 *
 * 使用约定：
 * - defaults 必须传模块级常量（保证引用稳定、且是"当前代码认定的默认值"）；
 * - 参数含义或素材尺度变化时必须升 version：旧保存值自动备份到 `<key>:legacy`
 *   供迁移核对，不静默沿用也不静默恢复默认。
 */

/** 保存状态：idle 初始未修改 / pending 防抖中 / saved 已落盘 / failed 写入失败 */
export type WorkshopSaveStatus = "idle" | "pending" | "saved" | "failed";

/** 已确认版本快照：label 供面板展示，params 为快照时的完整参数 */
export interface IWorkshopSnapshot<T> {
  id: string;
  label: string;
  savedAt: number;
  params: T;
}

export interface IWorkshopParamScope {
  /** 动效 id（demos/<motion-id>），必填 */
  demo: string;
  /** 模块名：同一动效内多面板 / 多方案时隔离配置，默认 "default" */
  module?: string;
}

export interface IUseWorkshopParamsResult<T> {
  params: T;
  status: WorkshopSaveStatus;
  /** 修改单个参数：立即生效并调度自动保存 */
  setParam: <K extends keyof T>(param: K, value: T[K]) => void;
  /** 批量合并修改 */
  patch: (partial: Partial<T>) => void;
  /** 用户主动恢复默认值（会覆盖保存值；此前调参可经快照找回） */
  reset: () => void;
  snapshots: IWorkshopSnapshot<T>[];
  /** 把当前参数存为快照（label 省略时按时间自动命名） */
  saveSnapshot: (label?: string) => void;
  restoreSnapshot: (id: string) => void;
  deleteSnapshot: (id: string) => void;
}

const STORAGE_PREFIX = "motion-ws:";
const SAVE_DEBOUNCE_MS = 300;
const MAX_SNAPSHOTS = 20;

interface ISavedEnvelope<T> {
  v: number;
  p: T;
}

function storageKey(scope: IWorkshopParamScope): string {
  return `${STORAGE_PREFIX}${scope.demo}:${scope.module ?? "default"}`;
}

function snapshotKey(key: string): string {
  return `${key}:snapshots`;
}

/** localStorage 读取：隐私模式 / JSON 损坏一律视为无历史（返回 null，不抛错） */
function readStorageJson<T>(key: string): T | null {
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : null;
  } catch {
    return null;
  }
}

/** localStorage 写入：失败返回 false（由调用方把状态如实标为 failed） */
function writeStorageJson(key: string, value: unknown): boolean {
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch {
    return false;
  }
}

/**
 * 初始化合并：保存值优先、defaults 补新增字段。
 * 版本不匹配时备份旧值到 `<key>:legacy` 后回退 defaults —— 不立即写回，
 * 防止初始化默认值覆盖历史配置（迁移后由代码升 version 正常读取）。
 */
function loadMergedParams<T extends object>(
  key: string,
  defaults: T,
  version: number,
): T {
  const saved = readStorageJson<ISavedEnvelope<Partial<T>>>(key);
  if (!saved || typeof saved !== "object" || typeof saved.p !== "object" || saved.p === null) {
    return defaults;
  }
  if (saved.v !== version) {
    writeStorageJson(`${key}:legacy`, saved);
    return defaults;
  }
  return { ...defaults, ...saved.p };
}

function loadSnapshots<T>(key: string): IWorkshopSnapshot<T>[] {
  const list = readStorageJson<IWorkshopSnapshot<T>[]>(snapshotKey(key));
  return Array.isArray(list) ? list : [];
}

function formatSnapshotLabel(savedAt: number): string {
  const two = (n: number) => String(n).padStart(2, "0");
  const date = new Date(savedAt);
  return `${two(date.getMonth() + 1)}-${two(date.getDate())} ${two(date.getHours())}:${two(date.getMinutes())}`;
}

export function useWorkshopParams<T extends object>(
  scope: IWorkshopParamScope,
  defaults: T,
  options: { version?: number } = {},
): IUseWorkshopParamsResult<T> {
  const key = storageKey(scope);
  const version = options.version ?? 1;

  const [params, setParams] = useState<T>(() => loadMergedParams(key, defaults, version));
  const [status, setStatus] = useState<WorkshopSaveStatus>("idle");
  const [snapshots, setSnapshots] = useState<IWorkshopSnapshot<T>[]>(() => loadSnapshots<T>(key));

  // 最新值镜像：setter 内不进 setState updater（避免 updater 副作用），统一经 ref 读当前值
  const paramsRef = useRef(params);
  paramsRef.current = params;
  const snapshotsRef = useRef(snapshots);
  snapshotsRef.current = snapshots;
  const defaultsRef = useRef(defaults);
  defaultsRef.current = defaults;

  const saveTimerRef = useRef<number | null>(null);
  const pendingRef = useRef<T | null>(null);

  /** 立即落盘：成功 / 失败如实反映到 status */
  const flushSave = useCallback(
    (next: T) => {
      const ok = writeStorageJson(key, { v: version, p: next } satisfies ISavedEnvelope<T>);
      setStatus(ok ? "saved" : "failed");
    },
    [key, version],
  );

  /** 防抖自动保存：完成一次调节后短窗内合并落盘，避免拖动滑杆时高频写 storage */
  const scheduleSave = useCallback(
    (next: T) => {
      pendingRef.current = next;
      setStatus("pending");
      if (saveTimerRef.current !== null) window.clearTimeout(saveTimerRef.current);
      saveTimerRef.current = window.setTimeout(() => {
        saveTimerRef.current = null;
        const pending = pendingRef.current;
        pendingRef.current = null;
        if (pending) flushSave(pending);
      }, SAVE_DEBOUNCE_MS);
    },
    [flushSave],
  );

  /** 冲刷未落盘的修改：路由切换卸载与页面关闭前各兜底一次（幂等） */
  const flushNow = useCallback(() => {
    const pending = pendingRef.current;
    if (saveTimerRef.current !== null) {
      window.clearTimeout(saveTimerRef.current);
      saveTimerRef.current = null;
    }
    pendingRef.current = null;
    if (pending) flushSave(pending);
  }, [flushSave]);

  useEffect(() => {
    const onBeforeUnload = () => flushNow();
    window.addEventListener("beforeunload", onBeforeUnload);
    return () => {
      window.removeEventListener("beforeunload", onBeforeUnload);
      flushNow();
    };
  }, [flushNow]);

  const setParam = useCallback(
    <K extends keyof T>(param: K, value: T[K]) => {
      const next = { ...paramsRef.current, [param]: value };
      paramsRef.current = next;
      setParams(next);
      scheduleSave(next);
    },
    [scheduleSave],
  );

  const patch = useCallback(
    (partial: Partial<T>) => {
      const next = { ...paramsRef.current, ...partial };
      paramsRef.current = next;
      setParams(next);
      scheduleSave(next);
    },
    [scheduleSave],
  );

  const reset = useCallback(() => {
    const next = { ...defaultsRef.current };
    paramsRef.current = next;
    setParams(next);
    scheduleSave(next);
  }, [scheduleSave]);

  const saveSnapshot = useCallback(
    (label?: string) => {
      const savedAt = Date.now();
      const snapshot: IWorkshopSnapshot<T> = {
        id: `snap-${savedAt}-${Math.random().toString(36).slice(2, 6)}`,
        label: label || formatSnapshotLabel(savedAt),
        savedAt,
        params: { ...paramsRef.current },
      };
      const next = [snapshot, ...snapshotsRef.current].slice(0, MAX_SNAPSHOTS);
      snapshotsRef.current = next;
      setSnapshots(next);
      // 快照是"已确认版本"：即时落盘，不走防抖
      writeStorageJson(snapshotKey(key), next);
    },
    [key],
  );

  const restoreSnapshot = useCallback(
    (id: string) => {
      const snapshot = snapshotsRef.current.find((item) => item.id === id);
      if (!snapshot) return;
      const next = { ...snapshot.params };
      paramsRef.current = next;
      setParams(next);
      scheduleSave(next);
    },
    [scheduleSave],
  );

  const deleteSnapshot = useCallback(
    (id: string) => {
      const next = snapshotsRef.current.filter((item) => item.id !== id);
      snapshotsRef.current = next;
      setSnapshots(next);
      writeStorageJson(snapshotKey(key), next);
    },
    [key],
  );

  return {
    params,
    status,
    setParam,
    patch,
    reset,
    snapshots,
    saveSnapshot,
    restoreSnapshot,
    deleteSnapshot,
  };
}
