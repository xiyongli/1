import React, { useEffect, useState } from "react";

function formatTime(date: Date) {
  return date.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" });
}

export function PhoneChrome() {
  const [time, setTime] = useState(() => formatTime(new Date()));

  useEffect(() => {
    const id = window.setInterval(() => setTime(formatTime(new Date())), 10_000);
    return () => window.clearInterval(id);
  }, []);

  return (
    <div className="pw-chrome" aria-hidden="true">
      <div className="pw-status">
        <span className="pw-status-time">{time}</span>
        <span className="pw-status-icons">
          <svg className="pw-status-signal" viewBox="0 0 18 12" width="18" height="12">
            <rect x="0" y="8" width="3" height="4" rx="0.6" fill="currentColor" />
            <rect x="5" y="5.5" width="3" height="6.5" rx="0.6" fill="currentColor" />
            <rect x="10" y="3" width="3" height="9" rx="0.6" fill="currentColor" />
            <rect x="15" y="0" width="3" height="12" rx="0.6" fill="currentColor" opacity="0.35" />
          </svg>
          <svg className="pw-status-wifi" viewBox="0 0 16 12" width="16" height="12">
            <path
              d="M1.2 4.2C4.6 1.4 11.4 1.4 14.8 4.2M3.6 6.6c2.3-1.8 6.5-1.8 8.8 0M6.1 9c1.1-.9 2.7-.9 3.8 0"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
            />
            <circle cx="8" cy="11" r="1.05" fill="currentColor" />
          </svg>
          <span className="pw-status-battery">
            <svg viewBox="0 0 25 12" width="25" height="12">
              <rect
                x="0.6"
                y="0.6"
                width="21"
                height="10.8"
                rx="2.2"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.2"
              />
              <rect x="2.2" y="2.3" width="16.2" height="7.4" rx="1.1" fill="currentColor" />
              <path d="M22.6 3.6h1.2c.6 0 1 .4 1 1v2.8c0 .6-.4 1-1 1h-1.2" fill="currentColor" />
            </svg>
          </span>
        </span>
      </div>
      <div className="pw-home" />
    </div>
  );
}
