import React, { type ReactNode } from "react";
import { DockSegment, DockTabs, type DockItem } from "./dockControls";

export function DockPanel({
  title,
  pages,
  activePage,
  onPageChange,
  tabs,
  activeTab,
  onTabChange,
  children,
  className,
}: {
  title?: string;
  pages?: DockItem[];
  activePage?: string;
  onPageChange?: (id: string) => void;
  tabs?: DockItem[];
  activeTab?: string;
  onTabChange?: (id: string) => void;
  children?: ReactNode;
  className?: string;
}) {
  return (
    <aside className={["pw-dock", className].filter(Boolean).join(" ")}>
      <div className="pw-dock-head">
        {title ? <span className="pw-dock-title">{title}</span> : null}
        {pages?.length && activePage && onPageChange ? (
          <div className="pw-nav-tier">
            <DockSegment items={pages} value={activePage} onChange={onPageChange} ariaLabel="页面" />
          </div>
        ) : null}
        {tabs?.length && activeTab && onTabChange ? (
          <div className="pw-nav-tier">
            <DockTabs items={tabs} value={activeTab} onChange={onTabChange} ariaLabel="调参分类" />
          </div>
        ) : null}
      </div>
      <div className="pw-dock-body">{children}</div>
    </aside>
  );
}
