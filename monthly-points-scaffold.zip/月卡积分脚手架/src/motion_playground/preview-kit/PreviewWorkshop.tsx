import React, {
  useCallback,
  useEffect,
  useState,
  type CSSProperties,
  type ReactNode,
} from "react";
import { PhoneFrame } from "./PhoneFrame";
import { DockPanel } from "./DockPanel";
import { DockGroup, type DockItem } from "./dockControls";

export type { DockItem };

export interface PreviewWorkshopGroup {
  id: string;
  title: string;
  lead?: string;
  defaultOpen?: boolean;
}

/** 从 hash 读全屏参数（#/motion/xxx?full=1）：分享链接直达全屏展示 */
function readFullFromHash(): boolean {
  const raw = window.location.hash.replace(/^#/, "");
  const query = raw.split("?")[1] ?? "";
  return query.split("&").includes("full=1");
}

export function PreviewWorkshop({
  phone,
  showChrome = true,
  phoneWidth = 375,
  phoneHeight = 812,
  dockWidth = 320,
  background,
  className,
  dockTitle,
  pages,
  activePage,
  onPageChange,
  tabs,
  activeTab,
  onTabChange,
  groups,
  renderGroup,
  dockChildren,
}: {
  phone: ReactNode;
  showChrome?: boolean;
  phoneWidth?: number;
  phoneHeight?: number;
  dockWidth?: number;
  background?: string;
  className?: string;
  dockTitle?: string;
  pages?: DockItem[];
  activePage?: string;
  onPageChange?: (id: string) => void;
  tabs?: DockItem[];
  activeTab?: string;
  onTabChange?: (id: string) => void;
  groups?: PreviewWorkshopGroup[];
  renderGroup?: (group: PreviewWorkshopGroup) => ReactNode;
  dockChildren?: ReactNode;
}) {
  const [full, setFull] = useState(readFullFromHash);
  const hasDock = Boolean(dockTitle || pages?.length || tabs?.length || groups?.length || dockChildren);

  /** 全屏状态双向同步进 URL：replaceState 不产生历史记录，进入后地址栏可直接复制分享 */
  const toggleFull = useCallback((next: boolean) => {
    setFull(next);
    const raw = window.location.hash.replace(/^#/, "");
    const basePath = raw.split("?")[0];
    const nextHash = next ? `${basePath}?full=1` : basePath;
    window.history.replaceState(null, "", `#${nextHash}`);
  }, []);

  // Esc 退出（仅全屏态监听；触屏设备用常驻 ✕ 浮钮退出）
  useEffect(() => {
    if (!full) return undefined;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") toggleFull(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [full, toggleFull]);

  // body 级全屏标记：供工坊外的路由浮层（返回按钮）隐藏自身
  useEffect(() => {
    document.body.classList.toggle("pw-full", full);
    return () => document.body.classList.remove("pw-full");
  }, [full]);

  // 设计尺寸经 --pw-design-* 注入，常态与全屏态的映射（contain 缩放 / 视口流式）由 CSS 接管
  const rootStyle = {
    "--pw-design-w": `${phoneWidth}px`,
    "--pw-design-h": `${phoneHeight}px`,
    ...(!full && hasDock ? { "--pw-dock-w": `${dockWidth}px` } : {}),
    ...(!full && background ? { background } : {}),
  } as CSSProperties;

  return (
    <div
      className={["pw-root", full ? "is-full" : null, hasDock ? null : "is-dockless", className]
        .filter(Boolean)
        .join(" ")}
      style={rootStyle}
    >
      {full ? (
        <button
          type="button"
          className="pw-fab pw-fab-exit"
          aria-label="退出全屏展示"
          onClick={() => toggleFull(false)}
        >
          ✕
        </button>
      ) : (
        <button
          type="button"
          className="pw-fab pw-fab-enter"
          aria-label="全屏展示"
          onClick={() => toggleFull(true)}
        >
          全屏展示
        </button>
      )}
      <div className="pw-row">
        <PhoneFrame showChrome={showChrome}>{phone}</PhoneFrame>
        {hasDock ? (
          <DockPanel
            title={dockTitle}
            pages={pages}
            activePage={activePage}
            onPageChange={onPageChange}
            tabs={tabs}
            activeTab={activeTab}
            onTabChange={onTabChange}
          >
            {dockChildren ??
              (groups ?? []).map((group) => (
                <DockGroup key={group.id} title={group.title} lead={group.lead} defaultOpen={group.defaultOpen}>
                  {renderGroup ? renderGroup(group) : <p className="pw-group-empty">待接入控件</p>}
                </DockGroup>
              ))}
          </DockPanel>
        ) : null}
      </div>
    </div>
  );
}
