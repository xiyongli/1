import React, { useState, type ReactNode } from "react";
import type { WorkshopSaveStatus } from "./useWorkshopParams";

export interface DockItem {
  id: string;
  label: string;
}

export function DockSegment({
  items,
  value,
  onChange,
  ariaLabel,
}: {
  items: DockItem[];
  value: string;
  onChange: (id: string) => void;
  ariaLabel?: string;
}) {
  return (
    <div className="pw-seg" role="tablist" aria-label={ariaLabel}>
      {items.map((item) => (
        <button
          key={item.id}
          type="button"
          role="tab"
          aria-selected={value === item.id}
          className={value === item.id ? "is-on" : undefined}
          onClick={() => onChange(item.id)}
        >
          {item.label}
        </button>
      ))}
    </div>
  );
}

export function DockTabs({
  items,
  value,
  onChange,
  ariaLabel,
}: {
  items: DockItem[];
  value: string;
  onChange: (id: string) => void;
  ariaLabel?: string;
}) {
  return (
    <div className="pw-tabs" role="tablist" aria-label={ariaLabel}>
      {items.map((item) => (
        <button
          key={item.id}
          type="button"
          role="tab"
          aria-selected={value === item.id}
          className={value === item.id ? "is-on" : undefined}
          onClick={() => onChange(item.id)}
        >
          {item.label}
        </button>
      ))}
    </div>
  );
}

export function DockGroup({
  title,
  lead,
  defaultOpen = false,
  open,
  onToggle,
  children,
}: {
  title: string;
  lead?: string;
  defaultOpen?: boolean;
  open?: boolean;
  onToggle?: () => void;
  children?: ReactNode;
}) {
  const [internalOpen, setInternalOpen] = useState(defaultOpen);
  const isOpen = open ?? internalOpen;
  const toggle = () => (onToggle ? onToggle() : setInternalOpen((v) => !v));

  return (
    <section className={isOpen ? "pw-group is-open" : "pw-group"}>
      <button type="button" className="pw-group-title" aria-expanded={isOpen} onClick={toggle}>
        <span>{title}</span>
        <span className="pw-group-mark">{isOpen ? "−" : "+"}</span>
      </button>
      {isOpen ? (
        <div className="pw-group-body">
          {lead ? <p className="pw-group-lead">{lead}</p> : null}
          {children}
        </div>
      ) : null}
    </section>
  );
}

export function DockNote({ children }: { children: ReactNode }) {
  return <p className="pw-note">{children}</p>;
}

export function ChipRow({ children }: { children: ReactNode }) {
  return <div className="pw-chip-row">{children}</div>;
}

/**
 * 数值滑杆行：标签 + range + 可输入数值框（失焦 / 回车提交，即时预览）。
 * editable 默认开启 —— 设计复盘要求"关键数值可输入并即时预览"，
 * 不允许只给一根拖不到精确值的滑杆。
 */
export function DockSlider({
  label,
  value,
  min,
  max,
  step = 1,
  onChange,
  format,
  editable = true,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  onChange: (value: number) => void;
  format?: (value: number) => string;
  /** 允许数值框直接输入；关闭则退回纯展示（format 自定义展示时建议关闭） */
  editable?: boolean;
}) {
  const [draft, setDraft] = useState<string | null>(null);

  const commit = (raw: string) => {
    setDraft(null);
    const parsed = Number(raw);
    if (!Number.isFinite(parsed)) return;
    const next = Math.min(max, Math.max(min, parsed));
    if (next !== value) onChange(next);
  };

  const display = format ? format(value) : String(value);

  return (
    <div className="pw-slider">
      <span className="pw-slider-name">{label}</span>
      <input
        className="pw-slider-input"
        type="range"
        aria-label={label}
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(event) => onChange(Number(event.target.value))}
      />
      {editable ? (
        <input
          className="pw-slider-value-input"
          type="text"
          inputMode="decimal"
          aria-label={`${label} 数值`}
          value={draft ?? display}
          onChange={(event) => setDraft(event.target.value)}
          onBlur={(event) => commit(event.target.value)}
          onKeyDown={(event) => {
            if (event.key === "Enter") event.currentTarget.blur();
            if (event.key === "Escape") setDraft(null);
          }}
        />
      ) : (
        <span className="pw-slider-value">{display}</span>
      )}
    </div>
  );
}

/** 保存状态徽标：与 useWorkshopParams 的 status 对接，三态如实可见（idle 未修改不展示） */
export function DockSaveState({ status }: { status: WorkshopSaveStatus }) {
  if (status === "idle") return null;
  const info: Record<Exclude<WorkshopSaveStatus, "idle">, { text: string; className: string }> = {
    pending: { text: "保存中…", className: "is-pending" },
    saved: { text: "已保存", className: "is-saved" },
    failed: { text: "保存失败", className: "is-failed" },
  };
  const state = info[status];
  return <span className={`pw-save-state ${state.className}`}>{state.text}</span>;
}

export interface IDockEffectToggle {
  /** 效果 id：与开工效果命名清单一一对应 */
  id: string;
  /** 效果名：沿用命名清单，禁止另起"流光""点击光"这类泛称 */
  label: string;
  /** 所在区域说明（如「底座上沿」），帮助区分同名近似效果 */
  area?: string;
  /** 当前是否显示 */
  visible: boolean;
  onVisibleChange: (visible: boolean) => void;
  /** 单独显示回调：传入后显示 solo 按钮（仅此效果可见，用于逐项核对） */
  onSolo?: () => void;
}

/**
 * 效果清单：设计复盘 01 类坑（名称相近改错对象）的对照控件。
 * 每行 = 命名清单条目 + 单独显示 / 显示开关，供"关闭该效果后只有目标区域改变"的核对方式。
 */
export function DockEffectList({ items }: { items: IDockEffectToggle[] }) {
  return (
    <div className="pw-fx-list">
      {items.map((item) => (
        <div key={item.id} className="pw-fx-item">
          <span className="pw-fx-name">
            {item.label}
            {item.area ? <em className="pw-fx-area">{item.area}</em> : null}
          </span>
          <span className="pw-fx-ops">
            {item.onSolo ? (
              <button type="button" className="pw-fx-op" onClick={item.onSolo}>
                solo
              </button>
            ) : null}
            <button
              type="button"
              className={item.visible ? "pw-fx-op is-on" : "pw-fx-op"}
              aria-pressed={item.visible}
              onClick={() => item.onVisibleChange(!item.visible)}
            >
              {item.visible ? "显示" : "隐藏"}
            </button>
          </span>
        </div>
      ))}
    </div>
  );
}

/** 快照条目的面板展示形态（与 IWorkshopSnapshot 结构兼容，不关心 params 类型） */
export interface IDockSnapshotItem {
  id: string;
  label: string;
  savedAt: number;
}

/**
 * 快照列表：已确认版本的保存 / 恢复入口（设计复盘"修改保护已有成果"落点）。
 * 与 useWorkshopParams 的快照 API 直接对接，重置前先存快照即可随时找回。
 */
export function DockSnapshots({
  snapshots,
  onSave,
  onRestore,
  onDelete,
}: {
  snapshots: IDockSnapshotItem[];
  onSave: () => void;
  onRestore: (id: string) => void;
  onDelete: (id: string) => void;
}) {
  return (
    <div className="pw-snap">
      <div className="pw-chip-row">
        <button type="button" onClick={onSave}>
          存为快照
        </button>
      </div>
      {snapshots.length > 0 ? (
        <div className="pw-snap-list">
          {snapshots.map((snapshot) => (
            <div key={snapshot.id} className="pw-snap-item">
              <span className="pw-snap-label">{snapshot.label}</span>
              <span className="pw-snap-ops">
                <button type="button" onClick={() => onRestore(snapshot.id)}>
                  恢复
                </button>
                <button type="button" onClick={() => onDelete(snapshot.id)}>
                  删除
                </button>
              </span>
            </div>
          ))}
        </div>
      ) : (
        <p className="pw-snap-empty">暂无快照：调到满意后先存一版，再继续试验。</p>
      )}
    </div>
  );
}
