import React, { useEffect, useRef, type ReactNode } from "react";
import { PhoneChrome } from "./PhoneChrome";

export function PhoneFrame({
  children,
  showChrome = true,
  className,
}: {
  children?: ReactNode;
  showChrome?: boolean;
  className?: string;
}) {
  const frameRef = useRef<HTMLDivElement>(null);

  // 工坊 fixed 桥基建：机型框的 transform 缩放会使框内 position: fixed 后代的定位基准
  // （containing block）变为机型框，场景按真视口坐标写入的 fixed 定位会错位 + 视觉二次缩放。
  // 这里把机型框视觉原点（getBoundingClientRect，含 transform）同步为 CSS 变量，
  // 供 demo 层用独立 translate/scale 属性对具体场景元素做反向补偿（缩放值复用 --pw-phone-scale）。
  // 窗口 resize 覆盖缩放/位置变化，ResizeObserver 覆盖机型切换（框布局尺寸变化）。
  useEffect(() => {
    const frame = frameRef.current;
    if (!frame) return undefined;
    const sync = () => {
      const rect = frame.getBoundingClientRect();
      frame.style.setProperty("--pw-frame-ox", `${rect.x}px`);
      frame.style.setProperty("--pw-frame-oy", `${rect.y}px`);
    };
    sync();
    window.addEventListener("resize", sync);
    const observer = new ResizeObserver(sync);
    observer.observe(frame);
    return () => {
      window.removeEventListener("resize", sync);
      observer.disconnect();
    };
  }, []);

  return (
    <div className="pw-phone-shell">
      <div className={["pw-phone-frame", className].filter(Boolean).join(" ")} ref={frameRef}>
        <div className="pw-phone-viewport">{children}</div>
        {showChrome ? <PhoneChrome /> : null}
      </div>
    </div>
  );
}
