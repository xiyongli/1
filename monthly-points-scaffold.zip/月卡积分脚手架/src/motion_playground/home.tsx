import React from 'react';

import { MOTION_REGISTRY } from './demos/registry';
import styles from './home.module.scss';

/**
 * 动效列表页（路由 '/'）：注册表驱动的工坊入口。
 * 使用 <a href="#/motion/..."> 天然支持新窗口打开与链接复制。
 */
export function MotionHome(): JSX.Element {
    const demos = MOTION_REGISTRY.filter(demo => !demo.hideFromHome);
    return (
        <div className={styles.home}>
            <header className={styles.topbar}>
                <div className={styles.brand}>
                    <span className={styles.brandDot} />
                    月卡积分动效工坊
                </div>
                <span className={styles.brandCount}>{demos.length} 个动效</span>
            </header>
            <main className={styles.main}>
                <div className={styles.sectionHead}>
                    <div className={styles.sectionTitle}>全部动效</div>
                    <p className={styles.sectionSub}>从列表进入工坊预览；每个动效独立分包，按需加载。</p>
                </div>
                {demos.length === 0 ? (
                    <div className={styles.emptyCard}>暂无可直接预览的动效。</div>
                ) : (
                    <div className={styles.grid}>
                        {demos.map((demo, index) => (
                            <a key={demo.id} className={styles.card} href={`#/motion/${demo.id}`}>
                                <div className={styles.cardMeta}>
                                    <span className={styles.cardIndex}>{String(index + 1).padStart(2, '0')}</span>
                                    <span className={styles.cardTag}>{demo.tags.join(' / ')}</span>
                                </div>
                                <div className={styles.cardTitle}>{demo.title}</div>
                                <p className={styles.cardDesc}>{demo.description}</p>
                                <div className={styles.cardFoot}>
                                    <span className={styles.cardRoute}>#/motion/{demo.id}</span>
                                    <span className={styles.cardArrow}>打开工坊 →</span>
                                </div>
                            </a>
                        ))}
                    </div>
                )}
            </main>
        </div>
    );
}
