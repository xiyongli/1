import { lazy } from "react";
import type { ComponentType } from "react";

/**
 * 动效注册表 —— 多动效工作区的唯一登记入口。
 *
 * 新增动效三步：
 * 1. 在本目录新建子目录 `<motion-id>/`（kebab-case），内含动效本体、workshop.tsx、样式与 assets；
 * 2. workshop.tsx 必须 default export 工坊组件（React.lazy 约定），并复用 preview-kit 原子件；
 * 3. 在下方数组追加一条注册项（id/标题/说明/tags/lazy 组件），路由 `#/motion/<motion-id>` 即自动可达。
 *
 * 每个 workshop 经 dynamic import 懒加载，未访问的动效不会进入首屏 bundle。
 */
export interface MotionDemoMeta {
  /** 路由 id，kebab-case，与子目录名一致 */
  id: string;
  /** 列表页展示标题 */
  title: string;
  /** 一句话说明动效内容与实现方式 */
  description: string;
  /** 实现方式标签（列表页展示），如 ['CSS']、['DdgyPlayer', 'Spine'] */
  tags: string[];
  /** 可通过路由访问，但不在默认列表展示 */
  hideFromHome?: boolean;
  /** 工坊组件（lazy），由注册表统一创建，禁止在组件内重复 lazy */
  Component: ComponentType;
}

export const MOTION_REGISTRY: MotionDemoMeta[] = [
  {
    id: "monthly-points-income",
    title: "积分金币入账",
    description: "点击商品气泡，金币聚集后飞向积分账户，数字滚动并显示入账增量。",
    tags: ["Three.js", "CSS"],
    hideFromHome: true,
    Component: lazy(() => import("./monthly-points-income/workshop")),
  },
];
