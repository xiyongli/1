import React from 'react';

import drink from './assets/qp1.png';
import kitchen from './assets/qp2.png';
import drawing from './assets/qp3.png';
import scenery from './assets/qp4.png';
import balanceHeader from './assets/balance-header.png';
import { usePointsIncome } from './usePointsIncome';

import './index.scss';

const bubbles = [
    { image: drink, label: '饮品', amount: 10 },
    { image: kitchen, label: '厨房好物', amount: 10 },
    { image: drawing, label: '绘画本', amount: 50 },
    { image: scenery, label: '山景好物', amount: 10 }
];

export function MonthlyPointsIncome(): JSX.Element {
    const { root, balance, points, gain, collected, collect, reset } = usePointsIncome();

    return (
        <div className="mp-stage">
            <div ref={root} className="mp-app" aria-label="积分金币入账动效">
                <div className="mp-scene">
                    {bubbles.map(({ image, label, amount }, index) => (
                        <button
                            key={label}
                            type="button"
                            className={`mp-bubble mp-bubble-${index + 1}${collected.has(index) ? ' is-collected' : ''}`}
                            disabled={collected.has(index)}
                            aria-label={`领取${label}积分 ${amount} 分`}
                            onClick={event => collect(event.currentTarget, index, amount)}
                        >
                            <img src={image} alt="" />
                        </button>
                    ))}
                    <button type="button" className="mp-reset" onClick={reset}>重置体验</button>
                </div>
                <div className="mp-panel">
                    <img className="mp-panel-art" src={balanceHeader} alt="" />
                    <div className="mp-balance">
                        <output ref={balance} aria-label="当前积分">{points}</output>
                        {gain && <span key={gain.sequence} className="mp-balance-gain" aria-hidden="true">+{gain.amount}</span>}
                    </div>
                </div>
            </div>
        </div>
    );
}
