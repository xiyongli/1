import modelUrl from './assets/coin.glb';
import haloUrl from './assets/water_ring_light.png';
import starUrl from './assets/sharp_star.png';
import './vendor/coin-reward.js';

export function createPointsRenderer(container: HTMLElement): CoinReward {
    const api = window.OrchardCoinReward;
    if (!api) throw new Error('Coin renderer unavailable');
    return api.createCoinReward({
        container,
        zIndex: 20,
        motion: { dustCount: 54, dim: 0, dimEarly: 1000000 },
        assets: { modelUrl, haloUrl, starUrl }
    });
}
