import { useEffect, useRef, useState } from 'react';

import { createPlayToken } from '@shared/motion/playToken';

const initialPoints = 148;

function localCenter(element: HTMLElement, root: HTMLElement) {
    const rect = element.getBoundingClientRect();
    const bounds = root.getBoundingClientRect();
    // The workshop scales the entire phone. Renderer coordinates use unscaled CSS pixels.
    return {
        x: (rect.left + rect.width / 2 - bounds.left) * root.clientWidth / bounds.width,
        y: (rect.top + rect.height / 2 - bounds.top) * root.clientHeight / bounds.height
    };
}

export function usePointsIncome() {
    const root = useRef<HTMLDivElement>(null);
    const balance = useRef<HTMLOutputElement>(null);
    const renderer = useRef<CoinReward>();
    const token = useRef(createPlayToken());
    const queue = useRef(Promise.resolve());
    const animations = useRef(new Set<Animation>());
    const claimed = useRef(new Set<number>());
    const total = useRef(initialPoints);
    const [points, setPoints] = useState(initialPoints);
    const [gain, setGain] = useState<{ amount: number; sequence: number }>();
    const [collected, setCollected] = useState<ReadonlySet<number>>(new Set());

    useEffect(() => {
        const activeAnimations = animations.current;
        return () => {
            token.current.cancel();
            activeAnimations.forEach(animation => animation.cancel());
            renderer.current?.destroy();
            renderer.current = undefined;
        };
    }, []);

    function reset() {
        token.current.cancel();
        token.current = createPlayToken();
        queue.current = Promise.resolve();
        renderer.current?.destroy();
        renderer.current = undefined;
        animations.current.forEach(animation => animation.cancel());
        root.current?.removeAttribute('data-coin-playing');
        claimed.current.clear();
        total.current = initialPoints;
        setCollected(new Set());
        setPoints(initialPoints);
        setGain(undefined);
    }

    function collect(button: HTMLButtonElement, id: number, amount: number) {
        const container = root.current;
        const target = balance.current;
        if (!container || !target || claimed.current.has(id)) return;
        const from = localCenter(button, container);
        const fromRatio = { x: from.x / container.clientWidth, y: from.y / container.clientWidth };
        const session = token.current;
        claimed.current.add(id);
        setCollected(new Set(claimed.current));

        queue.current = queue.current.then(async () => {
            if (!session.isCurrent()) return;
            const initialValue = total.current;
            const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
            const coordinates = () => {
                const width = container.clientWidth;
                return {
                    origin: { x: fromRatio.x * width, y: fromRatio.y * width },
                    to: localCenter(target, container)
                };
            };
            let incomeShown = false;
            const showIncome = () => {
                if (!session.isCurrent() || incomeShown) return;
                incomeShown = true;
                setGain({ amount, sequence: initialValue + amount });
            };
            const animate = async (element: HTMLElement, frames: Keyframe[], options: KeyframeAnimationOptions) => {
                const animation = element.animate(frames, options);
                animations.current.add(animation);
                try {
                    await animation.finished;
                } finally {
                    animations.current.delete(animation);
                    animation.cancel();
                }
            };

            try {
                if (!reduced) {
                    let player: CoinReward | undefined;
                    try {
                        player = renderer.current;
                        if (!player) {
                            const { createPointsRenderer } = await import(
                                /* webpackChunkName: "points-coin-3d" */ './createPointsRenderer'
                            );
                            if (!session.isCurrent()) return;
                            player = createPointsRenderer(container);
                            renderer.current = player;
                            await player.prepare();
                        }
                        if (!session.isCurrent()) return;
                        const { origin, to } = coordinates();
                        container.setAttribute('data-coin-playing', '');
                        await player.play({
                            from: origin,
                            to,
                            amount,
                            initialValue,
                            onIncome: showIncome,
                            onProgress: ({ value }) => {
                                if (session.isCurrent()) setPoints(Math.floor(value));
                            }
                        });
                        return;
                    } catch {
                        if (!session.isCurrent()) return;
                        player?.destroy();
                        renderer.current = undefined;
                    } finally {
                        if (session.isCurrent()) container.removeAttribute('data-coin-playing');
                    }
                }
                if (!reduced && typeof target.animate === 'function') {
                    const { origin, to } = coordinates();
                    const spark = document.createElement('span');
                    spark.className = 'mp-fallback-coin';
                    spark.textContent = '✦';
                    spark.setAttribute('aria-hidden', 'true');
                    spark.style.left = `${origin.x}px`;
                    spark.style.top = `${origin.y}px`;
                    container.appendChild(spark);
                    try {
                        await animate(spark, [
                            { transform: 'translate(-50%, -50%) scale(.5)', opacity: 0 },
                            { transform: 'translate(-50%, -75%) scale(1.2)', opacity: 1, offset: .25 },
                            { transform: `translate(calc(-50% + ${to.x - origin.x}px), calc(-50% + ${to.y - origin.y}px)) scale(.5)`, opacity: 1 }
                        ], { duration: 520, easing: 'ease-in-out' });
                    } finally {
                        spark.remove();
                    }
                    showIncome();
                    if (!session.isCurrent()) return;
                    const start = performance.now();
                    await new Promise<void>(resolve => {
                        const tick = (now: number) => {
                            if (!session.isCurrent()) {
                                resolve();
                                return;
                            }
                            const progress = Math.min(1, (now - start) / 430);
                            setPoints(Math.floor(initialValue + amount * (1 - (1 - progress) ** 2)));
                            if (progress < 1) requestAnimationFrame(tick);
                            else resolve();
                        };
                        requestAnimationFrame(tick);
                    });
                }
            } finally {
                if (session.isCurrent()) {
                    showIncome();
                    total.current = initialValue + amount;
                    setPoints(total.current);
                }
            }
        }).catch(() => {
            // Cancelling an in-flight fallback animation rejects its finished promise.
        });
    }

    return { root, balance, points, gain, collected, collect, reset };
}
