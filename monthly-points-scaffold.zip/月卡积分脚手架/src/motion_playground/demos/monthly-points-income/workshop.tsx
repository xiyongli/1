import React from 'react';

import { PreviewWorkshop } from '../../preview-kit/PreviewWorkshop';
import { MonthlyPointsIncome } from './index';

export default function MonthlyPointsWorkshop(): JSX.Element {
    return <PreviewWorkshop phone={<MonthlyPointsIncome />} />;
}
