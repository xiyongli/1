/**
 * 舞台等比缩放适配：按 750×1624 设计稿计算缩放比例，写入 CSS 变量 --stage-scale。
 *
 * 配合舞台样式中的 `transform: scale(var(--stage-scale))` 使用，
 * 取宽高缩放比的较小值（contain 适配），保证任意视口尺寸下
 * 750×1624 的舞台内容完整可见、居中展示、不产生滚动条。
 */
export function setupStageFit(stageWidth = 750, stageHeight = 1624): () => void {
    const refreshStageScale = () => {
        const { clientWidth, clientHeight } = document.documentElement;
        const scale = Math.min(clientWidth / stageWidth, clientHeight / stageHeight);
        document.documentElement.style.setProperty('--stage-scale', String(scale));
    };

    refreshStageScale();
    window.addEventListener('resize', refreshStageScale, { passive: true });
    return () => window.removeEventListener('resize', refreshStageScale);
}
