/**
 * 设置 rem 基准为恒定 100px（与 postcss-pxtorem 的 rootValue 一致）。
 *
 * 舞台采用固定 750×1624 设计稿 + transform 整体缩放适配视口（见 setupStageFit），
 * 视口适配由舞台缩放统一承担，rem 基准不再随视口变化，
 * 保证设计稿 px 值在舞台坐标系内 1:1 还原、任意视口下比例一致。
 */
export function setupRem(): void {
    const BaseFontSize = 100;
    document.documentElement.style.fontSize = `${BaseFontSize}px`;
}
