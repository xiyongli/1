declare module '*.module.scss' {
    const classNames: Readonly<Record<string, string>>;
    export default classNames;
}

declare module '*.css';

declare module '*.scss';

declare module '*.png' {
    const source: string;
    export default source;
}

declare module '*.jpg' {
    const source: string;
    export default source;
}

declare module '*.webp' {
    const source: string;
    export default source;
}

declare module '*.mp3' {
    const source: string;
    export default source;
}

declare module '@loadable/component' {
    import type { ComponentType } from 'react';
    const loadable: (loadFn: () => Promise<unknown>) => ComponentType;
    export default loadable;
}
