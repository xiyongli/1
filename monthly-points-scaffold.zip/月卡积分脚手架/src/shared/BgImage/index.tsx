import classNames from "classnames";
import React from "react";

import styles from "./index.module.scss";

interface IProps extends React.HTMLAttributes<HTMLDivElement> {
  /** 图片地址，可使用本地 import 结果或公开 URL。 */
  source: string;
  /** 图片替代文本；装饰图保持空字符串。 */
  alt?: string;
}

/** 无内部依赖的背景图片容器，替代原项目的内部 FunImage 封装。 */
export function BgImage({
  source,
  alt = "",
  className,
  children,
  ...restProps
}: IProps): JSX.Element {
  return (
    <div className={classNames(styles.container, className)} {...restProps}>
      <img className={styles.image} src={source} alt={alt} draggable={false} />
      <div className={styles.content}>{children}</div>
    </div>
  );
}
