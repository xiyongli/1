import React from 'react';
import { DisneyProvider } from './vendor/plugin-disney-Provider/disneyProvider';

/**
 * DdgyPlayer 运行所需的上下文适配层。
 *
 * DdgyScene 通过 useDisneyContext 读取宿主注入的能力（全部可选）：
 * - isDowngrade: 低端机降级开关，true 时跳过所有资源加载、直接渲染 fallback 静帧
 * - ddgyPlayProps: 全链路音频适配。不注入则 audio 图层静音；
 *   这里默认提供基于 HTMLAudioElement 的实现（同一 URL 复用同一实例，切状态/卸载时停止）
 */
const audioCache = new Map<string, HTMLAudioElement>();

const htmlAudioAdapter = {
    playFullUrlAudio: (url: string) => {
        if (!url) {
            return;
        }
        let audio = audioCache.get(url);
        if (!audio) {
            audio = new Audio(url);
            audio.preload = 'auto';
            audioCache.set(url, audio);
        }
        audio.currentTime = 0;
        audio.play().catch(() => undefined);
    },
    stopFullUrlAudio: (url: string) => {
        const audio = audioCache.get(url);
        if (audio) {
            audio.pause();
            audio.currentTime = 0;
        }
    }
};

export interface DdgyPlayerProviderProps {
    /** 低端机降级开关，true 时 DdgyScene 直接渲染 fallback 静帧（不可逆） */
    isDowngrade?: boolean;
    /** 覆盖默认的 HTMLAudio 音频适配（一般无需传入） */
    ddgyPlayProps?: { playFullUrlAudio?: (url: string) => void; stopFullUrlAudio?: (url: string) => void };
    children: React.ReactNode;
}

export const DdgyPlayerProvider = ({
    isDowngrade = false,
    ddgyPlayProps = htmlAudioAdapter,
    children
}: DdgyPlayerProviderProps) => (
    <DisneyProvider value={{ isDowngrade, ddgyPlayProps }}>{children}</DisneyProvider>
);
