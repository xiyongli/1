import React, { forwardRef, useEffect, useRef, useState } from 'react';

/**
 * 原 @pdd/disney Video 组件的本地替身（vendor 化后经 shims/animation.ts 直接导出）。
 *
 * 原组件依赖 @pdd/cartoon-request（视频信息上报）、@pdd/native-util（原生桥电量/端能力检查）
 * 等业务内部包，且其所在 animation 桶文件会全量 re-export animations / spine-animations 业务
 * 动画文件夹（引用大量业务内部包），与动效脚手架无关。
 *
 * 本替身保留纯 Web 行为，与原组件对 DdgyPlayer 的契约保持一致：
 * - forwardRef 暴露 <video> 元素（VideoLayerHost 通过 ref 做 currentTime 逐帧同步）
 * - isSupportVideo=false 或加载出错 → 隐藏 video、以 backgroundImage 展示兜底图并回调 onError
 * - onLoadedMetadata / onCanPlay / onEnded / onVideoStart（首帧 currentTime>=0.01 触发一次）透传
 */
export interface VideoShimProps extends React.VideoHTMLAttributes<HTMLVideoElement> {
    /** 播放视频的 src */
    videoPath: string;
    /** 首帧图 */
    posterPath: string;
    /** 兜底图，未传入则默认使用首帧图 */
    fallbackUrl?: string;
    /** 是否支持播放视频，低端机传 false */
    isSupportVideo: boolean;
    /** 视频容器的自定义样式 */
    videoStyle?: React.CSSProperties;
    /** 视频标签的自定义样式 */
    videoTagStyle?: React.CSSProperties;
    /** 视频类型，默认 video/mp4 */
    videoType?: string;
    /** 是否循环播放 */
    loop?: boolean;
    /** 是否静音播放 */
    muted?: boolean;
    /** 是否自动播放 */
    autoPlay?: boolean;
    /** 视频错误回调 */
    onError?: (err: unknown) => void;
    /** 可以播放回调 */
    onCanPlay?: () => void;
    /** 视频元数据加载好时触发的回调 */
    onLoadedMetadata?: () => void;
    /** 播放完成回调 */
    onEnded?: () => void;
    /** 视频真实开始播放回调（currentTime >= 0.01 时触发一次） */
    onVideoStart?: () => void;
}

export const Video = forwardRef<HTMLVideoElement, VideoShimProps>(function Video(props, ref) {
    const {
        videoPath,
        videoType = 'video/mp4',
        posterPath,
        fallbackUrl = posterPath,
        isSupportVideo,
        videoStyle,
        videoTagStyle,
        loop = true,
        autoPlay = true,
        muted = true,
        onError,
        onCanPlay,
        onEnded,
        onLoadedMetadata,
        onVideoStart,
        onTimeUpdate: onTimeUpdateFromProps,
        ...otherVideoProps
    } = props;

    const [isPlayVideo, setIsPlayVideo] = useState(true);
    const videoStartTriggeredRef = useRef(false);

    // 回调 ref 化，避免依赖数组导致的重复触发
    const onErrorRef = useRef(onError);
    onErrorRef.current = onError;

    useEffect(() => {
        // 不支持视频：与原组件一致，直接走错误回调（上层据此计入加载完成并渲染兜底）
        if (!isSupportVideo) {
            setIsPlayVideo(false);
            onErrorRef.current?.({ err: 'isSupportVideo=false' });
        }
    }, [isSupportVideo]);

    const handleError = (err?: unknown) => {
        setIsPlayVideo(false);
        onErrorRef.current?.(err);
    };

    const showFallback = !isSupportVideo || !isPlayVideo;

    return (
        <div style={videoStyle}>
            <div
                style={{
                    width: '100%',
                    height: '100%',
                    backgroundImage: `url(${showFallback ? fallbackUrl : posterPath})`
                }}
            >
                {isSupportVideo && isPlayVideo ? (
                    <video
                        ref={ref}
                        style={videoTagStyle}
                        autoPlay={autoPlay}
                        loop={loop}
                        muted={muted}
                        playsInline
                        poster={posterPath}
                        onCanPlay={() => onCanPlay?.()}
                        onLoadedMetadata={() => onLoadedMetadata?.()}
                        onError={() => handleError()}
                        onEnded={() => onEnded?.()}
                        onTimeUpdate={event => {
                            const currentTime = (event.target as HTMLVideoElement).currentTime;
                            if (currentTime >= 0.01 && !videoStartTriggeredRef.current) {
                                videoStartTriggeredRef.current = true;
                                onVideoStart?.();
                            }
                            onTimeUpdateFromProps?.(event);
                        }}
                        {...otherVideoProps}
                    >
                        <source src={videoPath} type={videoType} />
                    </video>
                ) : null}
            </div>
        </div>
    );
});
