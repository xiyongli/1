/**
 * Video 组件的本地出口。原 @pdd/disney es/animation 桶文件除导出干净的插件组件
 * （Video / ApngImg / AlphaVideo / audioManager 等）外，还全量 re-export animations /
 * spine-animations 两个业务动画文件夹，后者引用 @pdd/cartoon-react-common、
 * @pdd/cartoon-request、@pdd/monitor/pmm 等大量业务内部包，与动效脚手架无关。
 * vendor 化后 VideoLayerHost 直接 import 本文件，不再依赖 webpack 模块替换。
 *
 * 需要其余导出（ApngImg / AlphaVideo / WebglVideo / audioManager / audioHelper）时，
 * 先确认对应 plugin-* 文件夹的依赖干净，再逐个补充 re-export。
 */
export { Video } from './Video';
export type { VideoShimProps } from './Video';
