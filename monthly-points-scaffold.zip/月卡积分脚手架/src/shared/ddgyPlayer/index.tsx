/**
 * DdgyPlayer 统一出口。
 *
 * 运行时源码已从 @pdd/disney 整体抽取为本地 vendor（见 ./vendor/，抽取范围与差异说明
 * 见 vendor 内文件头注释），深路径导入 vendor 下的原始组件（绕开插件入口的 loadable 懒
 * 加载包装，由 webpack 自行做 chunk 划分）。生成动效代码时只允许从这里导入。
 */
import DdgyPlayer, { type DdgyPlayerProps, type CssRegisterEntry } from './vendor/plugin-ddgy-player/src/DdgyPlayer';

import { DdgyPlayerProvider } from './DdgyPlayerProvider';

export { DdgyPlayerProvider };
export type { DdgyPlayerProviderProps } from './DdgyPlayerProvider';
export type { DdgyPlayerProps, CssRegisterEntry };

export { useDdgyPlayer, createLazyScene } from './vendor/plugin-ddgy-player/src/hooks';

export type {
    ComposeLayerType,
    LayerTimelineClip,
    ComposePlaybackRange,
    ComposeLoopMode,
    ComposeTransform,
    SlotSwap,
    FallbackFrame,
    FallbackDomProps,
    ComposeLayerBase,
    ComposeImageLayer,
    ComposeVideoLayer,
    ComposeCssLayer,
    ComposeSpineLayer,
    ComposeSpineLayerMeta,
    ComposeAudioLayer,
    ComposeLayer,
    ComposeState,
    ComposeManifest
} from './vendor/plugin-ddgy-player/src/@types/types';

export default DdgyPlayer;
