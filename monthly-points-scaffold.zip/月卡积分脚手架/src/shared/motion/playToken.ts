/**
 * 播放会话令牌 —— 动效防重入的通用最小件（设计复盘 07 类坑的统一解法）。
 *
 * 功能范围：命令式动效（timeout / rAF / tween 回调 / 音效收尾）在新一次触发
 * 进入时让旧会话失效，防止旧计时、旧回调继续改写新状态。
 *
 * 用法约定：
 * ```ts
 * const tokenRef = useRef<IPlayToken | null>(null);
 * function play() {
 *   tokenRef.current?.cancel(); // 旧播放立即失效
 *   const token = createPlayToken();
 *   tokenRef.current = token;
 *   window.setTimeout(() => {
 *     if (!token.isCurrent()) return; // 已被更新的播放打断：不再生效
 *     // ... 收尾逻辑
 *   }, delay);
 * }
 * ```
 *
 * cancel 幂等；令牌只做"是否仍然有效"的判断，不持有任何定时器或资源，
 * 不替代 MOTION_RULES 的卸载清理义务（tween kill / removeEventListener / dispose 照做）。
 */

export interface IPlayToken {
  /** 当前会话是否仍然有效（未被更新的播放取消） */
  isCurrent(): boolean;
  /** 使本令牌失效（幂等）；由"新播放进入"或"卸载清理"调用 */
  cancel(): void;
}

export function createPlayToken(): IPlayToken {
  const session = { active: true };
  return {
    isCurrent: () => session.active,
    cancel: () => {
      session.active = false;
    },
  };
}
