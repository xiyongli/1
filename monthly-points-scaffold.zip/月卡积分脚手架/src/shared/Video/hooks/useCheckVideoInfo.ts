/**
 * Shim：@pdd/disney Video 的 useCheckVideoInfo（开发诊断 hook）。
 *
 * 原实现仅在 dev/staging 环境请求视频信息接口（cartoonRequest →
 * /api/fun-gateway/query/video/info），检测 H.265 编码（客户端会崩溃）与码率过高。
 * demo/脚手架工程禁业务接口，剥离请求仅保留 hook 签名（no-op）；
 * 如需恢复诊断能力，请在业务工程内使用原 @pdd/disney 版本。
 */
type Options = {
    /** 视频链接 */
    videoPath: string;
    /** 自定义处理视频信息（仅原实现在本地、预发环境执行） */
    onHandleVideoInfo?: (avInfoVo: unknown) => void;
};

export function useCheckVideoInfo(_options: Options): void {
    /* no-op：接口依赖剥离，签名保留以维持 Video 组件调用链不变 */
}
