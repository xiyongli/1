/**
 * Shim：@pdd/platform-util / @pdd/native-util（仅 Video 组件用到的成员）。
 * demo/脚手架为纯浏览器环境：platform 恒为 Web、isNativePlatform 恒 false，
 * Video 内的 native 分支（电量检测 bridge 调用）永不触发；invokeBridgeCallNativeFun
 * 保留签名做防御性兜底（万一被调用给出明确提示而非静默崩溃）。
 */
export enum PLATFORM {
    PddIOS = 'PddIOS',
    PddAndroid = 'PddAndroid',
    WxApp = 'WxApp',
    Web = 'Web'
}

export interface IPlatformInfo {
    platform: PLATFORM;
    /** 是否运行在客户端（native 容器）内 */
    isNativePlatform: boolean;
}

export function getCurrentPlatform(): IPlatformInfo {
    return { platform: PLATFORM.Web, isNativePlatform: false };
}

/**
 * Shim：@pdd/native-util 的 bridge 调用。
 * demo 环境无 native bridge（getCurrentPlatform().isNativePlatform 恒 false，
 * Video 的电量检测分支不会走到这里）；保留签名仅作防御性兜底。
 */
export function invokeBridgeCallNativeFun(...args: unknown[]): Promise<Record<string, unknown>> {
    console.warn('[shared/Video] native bridge 不可用（浏览器环境），调用被忽略：', args[0], args[1]);
    return Promise.resolve({});
}
