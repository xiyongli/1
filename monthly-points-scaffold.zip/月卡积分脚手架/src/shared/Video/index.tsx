/* eslint-disable react-hooks/exhaustive-deps -- 迁移组件：挂载期一次性检查的空依赖数组为原实现既定语义，保持原样 */
import React, { forwardRef, useEffect, useRef, useState } from 'react';

import { getCurrentPlatform, invokeBridgeCallNativeFun, PLATFORM } from './platformShim';

import './styles.scss';
import { useCheckVideoInfo } from './hooks/useCheckVideoInfo';
import { useMemoizedFn } from 'ahooks';

interface IProps extends React.VideoHTMLAttributes<HTMLVideoElement> {
    /** 播放视频的src */
    videoPath: string;
    /** 首帧图 */
    posterPath: string;
    /** 兜底图，若未传入则默认使用首帧图 */
    fallbackUrl?: string;
    /** 是否支持播放视频，低端机传false */
    isSupportVideo: boolean;
    /** 视频容器的自定义样式 */
    videoStyle?: React.CSSProperties;
    /** 视频标签的自定义样式 */
    videoTagStyle?: React.CSSProperties;
    /** 视频类型，默认video/mp4 */
    videoType?: string;
    /** 是否循环播放 */
    loop?: boolean;
    /** 是否静音播放 */
    muted?: boolean;
    /** 是否自动播放 */
    autoPlay?: boolean;
    /** 视频错误回调 */
    onError?: (err: unknown) => void;
    /** 可以播放（⚠️注意，autoPlay=false的情况下，iOS由于不会preload视频，导致触发不了该事件），推荐改用 onLoadedMetadata */
    onCanPlay?: () => void;
    /** 视频元数据加载好时触发的回调 */
    onLoadedMetadata?: () => void;
    /** 播放完成回调 */
    onEnded?: () => void;
    /** 在指定时长内未触发 onLoadedMetadata 则关闭视频，默认关闭 */
    closeIfNoMetadata?: boolean;
    /** 在指定时长内未触发 onVideoStart 则关闭视频，默认关闭 */
    closeIfNoVideoStart?: boolean;
    /** 超时时长，单位毫秒，默认 2000ms */
    metadataTimeout?: number;
    /** 视频真实开始播放，通常用于处理视频播放和spine/ae动画的播放卡点 */
    onVideoStart?: () => void;
}

let isLowPowerMode = false;

export const Video = forwardRef<HTMLVideoElement, IProps>(function Video(props, ref) {
    const {
        videoPath,
        videoType = 'video/mp4',
        posterPath,
        fallbackUrl = posterPath,
        isSupportVideo,
        videoStyle,
        videoTagStyle,
        loop = true,
        autoPlay = true,
        muted = true,
        onError,
        onCanPlay,
        onEnded,
        onLoadedMetadata,
        closeIfNoMetadata = false,
        closeIfNoVideoStart = false,
        metadataTimeout = 2000,
        onTimeUpdate: onTimeUpdateFromProps,
        onVideoStart: onVideoStartFromProps,
        ...otherVideoProps
    } = props;
    /** 是否播放视频 */
    const [isPlayVideo, setIsPlayVideo] = useState<boolean>(true);
    const metadataTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
    /** 标记 onVideoStart 是否已触发，避免重复触发 */
    const videoStartTriggeredRef = useRef<boolean>(false);

    const onVideoCanPlay = useMemoizedFn(() => {
        onCanPlay?.();
    });

    const onVideoEnded = useMemoizedFn(() => {
        onEnded?.();
    });

    const onErrorCallBack = useMemoizedFn((err?: unknown) => {
        setIsPlayVideo(false);
        onError?.(err);
    });

    const onVideoLoadedMetadata = useMemoizedFn((e: React.SyntheticEvent<HTMLVideoElement>) => {
        if (autoPlay && muted && getCurrentPlatform().platform === PLATFORM.PddIOS) {
            e.currentTarget?.play()?.catch(err => {
                if (err.name === 'NotAllowedError') {
                    // iOS 不让播放（低电量）
                    isLowPowerMode = true;
                    onErrorCallBack();
                }
            });
        }
        if (metadataTimerRef.current) {
            clearTimeout(metadataTimerRef.current);
            metadataTimerRef.current = null;
        }
        onLoadedMetadata?.();
    });

    const onVideoStart = () => {
        if (metadataTimerRef.current) {
            clearTimeout(metadataTimerRef.current);
            metadataTimerRef.current = null;
        }
        onVideoStartFromProps?.();
    };

    useCheckVideoInfo({ videoPath });

    useEffect(() => {
        // 如果不支持播放，直接执行错误回调, 否则去获取电池信息
        if (!isSupportVideo) {
            onErrorCallBack();
            return;
        }
        if (process.env.NODE_ENV === 'development') {
            setIsPlayVideo(true);
            return;
        }
        if (navigator.userAgent.includes('TBS')) {
            onErrorCallBack({ err: 'navigator=>TBS' });
            return;
        }
        if (navigator.userAgent.includes('miniProgram') || getCurrentPlatform().platform === PLATFORM.WxApp) {
            onErrorCallBack({ err: 'miniProgram' });
            return;
        }

        if (isLowPowerMode) {
            onErrorCallBack({ isLowPowerMode: true });
            return;
        }

        if (getCurrentPlatform().isNativePlatform) {
            invokeBridgeCallNativeFun('AMDevice', 'getBatteryInfo', undefined, '4.48.0', '4.48.0')
                .then(res => {
                    if (res?.isLowPowerMode) {
                        isLowPowerMode = true;
                        onErrorCallBack(res);
                        return;
                    }
                    setIsPlayVideo(true);
                })
                .catch(err => {
                    onErrorCallBack(err);
                });
        } else {
            setIsPlayVideo(true);
        }
    }, []);

    useEffect(() => {
        if ((closeIfNoMetadata || closeIfNoVideoStart) && isSupportVideo && isPlayVideo) {
            if (metadataTimerRef.current) {
                clearTimeout(metadataTimerRef.current);
                metadataTimerRef.current = null;
            }
            metadataTimerRef.current = setTimeout(() => {
                onErrorCallBack({ err: 'onLoadedMetadata timeout' });
            }, metadataTimeout);
        }
        return () => {
            if (metadataTimerRef.current) {
                clearTimeout(metadataTimerRef.current);
                metadataTimerRef.current = null;
            }
        };
    }, []);

    return (
        <div className='disney-video-top' style={videoStyle}>
            <div
                className='disney-video-wrap'
                style={{
                    backgroundImage: `url(${!isSupportVideo || !isPlayVideo ? fallbackUrl : posterPath})`
                }}
            >
                {isSupportVideo && isPlayVideo ? (
                    <video
                        ref={ref}
                        className='disney-video'
                        style={videoTagStyle}
                        autoPlay={autoPlay}
                        loop={loop}
                        muted={muted}
                        playsInline
                        poster={posterPath}
                        onCanPlay={onVideoCanPlay}
                        onLoadedMetadata={onVideoLoadedMetadata}
                        onError={onErrorCallBack}
                        onEnded={onVideoEnded}
                        onTimeUpdate={event => {
                            const currentTime = (event.target as HTMLVideoElement).currentTime;
                            if (currentTime >= 0.01 && !videoStartTriggeredRef.current) {
                                videoStartTriggeredRef.current = true;
                                onVideoStart?.();
                            }
                            onTimeUpdateFromProps?.(event);
                        }}
                        {...otherVideoProps}
                    >
                        <source src={videoPath} type={videoType} />
                    </video>
                ) : null}
            </div>
        </div>
    );
});
