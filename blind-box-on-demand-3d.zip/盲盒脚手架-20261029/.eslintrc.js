module.exports = {
    root: true,
    env: { browser: true, es2021: true, node: true },
    parser: '@typescript-eslint/parser',
    parserOptions: { ecmaVersion: 2021, sourceType: 'module', ecmaFeatures: { jsx: true } },
    plugins: ['@typescript-eslint', 'react-hooks'],
    extends: ['eslint:recommended', 'plugin:@typescript-eslint/recommended'],
    rules: {
        '@typescript-eslint/no-explicit-any': 'error',
        '@typescript-eslint/no-unused-vars': [
            'warn',
            { argsIgnorePattern: '^_', varsIgnorePattern: '^_', caughtErrorsIgnorePattern: '^_' }
        ],
        'react-hooks/rules-of-hooks': 'error',
        'react-hooks/exhaustive-deps': 'error'
    },
    overrides: [
        {
            files: ['*.js'],
            rules: { '@typescript-eslint/no-var-requires': 'off' }
        },
        {
            // vendored 第三方代码：保持原包实现原样，不套用本工程 lint 规则
            files: ['src/shared/ddgyPlayer/vendor/**'],
            rules: {
                '@typescript-eslint/no-explicit-any': 'off',
                '@typescript-eslint/no-non-null-assertion': 'off',
                '@typescript-eslint/ban-ts-comment': 'off',
                '@typescript-eslint/ban-types': 'off',
                '@typescript-eslint/no-empty-function': 'off',
                '@typescript-eslint/no-unused-vars': 'off',
                'react-hooks/exhaustive-deps': 'off'
            }
        },
        {
            // TearBox 迁移动效源码：保持原项目实现原样，不套用本工程 lint 规则
            // （新写的 shims/ mock/ 装配层 index.tsx / workshop.tsx 不在此列，保持严格检查）
            files: [
                'src/motion_playground/demos/tear-box/source/**',
                'src/motion_playground/demos/tear-box/debug/**',
                'src/motion_playground/demos/tear-box/ui/**',
                'src/motion_playground/demos/tear-box/runtime/**',
                'src/motion_playground/demos/tear-box/TearBoxRoot.tsx',
                'src/motion_playground/demos/tear-box/BlindBoxDetailExperience.tsx',
                'src/motion_playground/demos/tear-box/BlindBoxOpenExperience.tsx',
                'src/motion_playground/demos/tear-box/type.ts',
                'src/motion_playground/demos/tear-box/publishedConfigLoader.ts',
                'src/motion_playground/demos/tear-box/resolvePublishedConfig.ts',
                'src/motion_playground/demos/tear-box/homePreload.ts',
                'src/motion_playground/demos/tear-box/mediaUrls.ts',
                'src/motion_playground/demos/tear-box/ensurePublishedConfig.ts',
                // 原项目整文件迁移的 shim（@ts-nocheck 带病运行，见文件头注释）
                'src/motion_playground/demos/tear-box/shims/dynamicResolution.ts',
                // NewbieGuideCom 迁移动效源码（同 TearBox 模式：原项目实现原样）
                'src/motion_playground/demos/newbie-guide/NewbieGuideCom.tsx',
                // shared/Video：业务侧指定代码原样迁移（@pdd/disney Video 组件）
                'src/shared/Video/index.tsx'
            ],
            rules: {
                '@typescript-eslint/no-empty-function': 'off',
                '@typescript-eslint/no-inferrable-types': 'off',
                '@typescript-eslint/no-unused-vars': 'off',
                '@typescript-eslint/no-non-null-assertion': 'off',
                '@typescript-eslint/ban-ts-comment': 'off',
                'react-hooks/exhaustive-deps': 'off'
            }
        }
    ],
    ignorePatterns: ['dist/', 'node_modules/']
};
