import React from "react";
import ReactDOM from "react-dom";

import { MotionPlayground } from "@playground/index";
import { setupRem } from "@utils/setupRem";
import { setupStageFit } from "@utils/setupStageFit";

// WindiCSS 虚拟模块（windicss-webpack-plugin 按 windi.config.ts 生成，含 TearBox 迁移场景用到的 utilities）
import "windi.css";

import "@styles/global.scss";

setupRem();
setupStageFit();

ReactDOM.render(<MotionPlayground />, document.getElementById("root"));
